/* Site header: brand lockup, search field, primary nav, quiz CTA, burger. */
function VNHeader({ onNav, current }) {
  const { Search } = window.VNIcons;
  const [open, setOpen] = React.useState(false);
  const go = (id) => (e) => { e.preventDefault(); onNav(id); setOpen(false); };
  const links = [
    ['home', 'Главная', true],
    ['catalog', 'Каталог вузов'],
    ['regions', 'Регионы'],
    ['directions', 'Направления'],
    ['compare', 'Сравнение'],
    ['test', 'Тест'],
  ];
  return (
    <header className={'site-header' + (open ? ' nav-open' : '')}>
      <div className="container">
        <div className="header-top">
          <a className="brand" href="#" onClick={go('home')}>
            <img className="brand-mark" src="../../assets/logo.png" alt="" />
            <span>MainExperts<span style={{ color: 'var(--text-muted)', fontWeight: 500 }}> · ВУЗ-навигатор</span></span>
          </a>
          <div className="header-actions">
            <a className="nav-cta" href="#" onClick={go('test')}>Пройти тест</a>
            <button className="nav-toggle" aria-label="Меню" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
              <span className="nav-toggle-bars" />
            </button>
          </div>
        </div>
        <div id="site-search" style={{ flex: '1 1 300px', maxWidth: 430 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '9px 14px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-s)', color: 'var(--text-muted)', boxShadow: 'var(--shadow-1)' }}>
            <Search size={17} />
            <input placeholder="Поиск вуза, города, направления…" onFocus={go('catalog')} readOnly
              style={{ border: 0, outline: 'none', background: 'transparent', font: 'inherit', color: 'var(--text)', width: '100%', cursor: 'pointer' }} />
          </label>
        </div>
        <nav className="site-nav">
          {links.map(([id, label, home]) => (
            <a key={id} href="#" className={home ? 'nav-home' : undefined}
              aria-current={current === id ? 'page' : undefined}
              style={current === id ? { color: 'var(--text)', fontWeight: 600 } : undefined}
              onClick={go(id)}>{label}</a>
          ))}
        </nav>
      </div>
    </header>
  );
}
window.VNHeader = VNHeader;
