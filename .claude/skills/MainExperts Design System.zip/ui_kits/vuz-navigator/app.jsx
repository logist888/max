/* App shell — screen state + navigation for the click-through. */
function VNApp() {
  const [screen, setScreen] = React.useState('home');
  const [vuz, setVuz] = React.useState(null);
  const top = () => { try { window.scrollTo(0, 0); } catch (e) {} };
  const nav = (s) => { setScreen(s); top(); };
  const openVuz = (v) => { setVuz(v); setScreen('vuz'); top(); };

  let body;
  switch (screen) {
    case 'catalog':
    case 'regions':
    case 'directions':
      body = <window.VNCatalog onOpenVuz={openVuz} />; break;
    case 'vuz':
      body = <window.VNVuz vuz={vuz || window.VN_DATA.vuzy[0]} onNav={nav} onOpenVuz={openVuz} />; break;
    case 'compare':
      body = <window.VNCompare onOpenVuz={openVuz} />; break;
    case 'test':
      body = <window.VNQuiz onNav={nav} />; break;
    default:
      body = <window.VNHome onNav={nav} onOpenVuz={openVuz} />;
  }
  const current = screen === 'vuz' ? 'catalog' : screen;
  return (
    <React.Fragment>
      <window.VNHeader onNav={nav} current={current} />
      {body}
      <window.VNFooter />
      <window.VNConv.ExitIntent onQuiz={() => nav('test')} />
    </React.Fragment>
  );
}
const VN_ROOT_EL = document.getElementById('root');
VN_ROOT_EL._vnRoot = VN_ROOT_EL._vnRoot || ReactDOM.createRoot(VN_ROOT_EL);
VN_ROOT_EL._vnRoot.render(<VNApp />);
