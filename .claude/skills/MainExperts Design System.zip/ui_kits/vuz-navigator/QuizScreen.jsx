/* Quiz /test/ — the conversion bridge. 5 questions, no personal data. Two
   outcomes: "know where you're going" → route through the catalog;
   "still exploring" → risk zones + a bridge to the diagnostics goal (UTM). */
function VNQuiz({ onNav }) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const { Button, FilterChip, ZoneChip, Callout, Card } = DS;
  const I = window.VNIcons;

  const QUESTIONS = [
    { id: 'who', q: 'Кто проходит тест?', multi: false, opts: ['9 класс', '10 класс', '11 класс', 'Выпускник / СПО', 'Родитель'] },
    { id: 'sure', q: 'Насколько определились с выбором?', multi: false, opts: ['Уверен(а) в направлении', 'Есть 2–3 варианта', 'Совсем не определился(ась)'] },
    { id: 'decided', q: 'Что уже решено?', multi: true, opts: ['Город', 'Направление', 'Конкретный вуз', 'Пока ничего'] },
    { id: 'ugs', q: 'Какие области ближе?', multi: true, opts: ['ИТ и математика', 'Экономика и управление', 'Инженерия', 'Гуманитарные науки', 'Медицина', 'Ещё не знаю'] },
    { id: 'stop', q: 'Что мешает решиться?', multi: false, opts: ['Не знаю своих сильных сторон', 'Боюсь ошибиться с профессией', 'Не понимаю рынок труда', 'Ничего, всё ясно'] },
  ];

  const [step, setStep] = React.useState(0);
  const [ans, setAns] = React.useState({});
  const done = step >= QUESTIONS.length;

  const pick = (q, opt) => setAns((a) => {
    if (!q.multi) return { ...a, [q.id]: opt };
    const cur = new Set(a[q.id] || []);
    cur.has(opt) ? cur.delete(opt) : cur.add(opt);
    return { ...a, [q.id]: [...cur] };
  });
  const isPicked = (q, opt) => (q.multi ? (ans[q.id] || []).includes(opt) : ans[q.id] === opt);
  const answered = (q) => (q.multi ? (ans[q.id] || []).length > 0 : !!ans[q.id]);

  const pct = Math.round((Math.min(step, QUESTIONS.length) / QUESTIONS.length) * 100);

  if (!done) {
    const q = QUESTIONS[step];
    return (
      <main className="container" style={{ maxWidth: 720 }}>
        <nav className="breadcrumbs"><a href="#" onClick={(e) => { e.preventDefault(); onNav('home'); }}>Главная</a> → <span aria-current="page">Тест</span></nav>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'var(--space-6)' }}>
          <span className="eyebrow" style={{ margin: 0 }}>Вопрос {step + 1} из {QUESTIONS.length}</span>
          <span className="filters-count" style={{ fontVariantNumeric: 'tabular-nums' }}>{pct}%</span>
        </div>
        <div style={{ height: 8, borderRadius: 999, background: 'var(--surface-2)', overflow: 'hidden', margin: '8px 0 var(--space-6)' }}>
          <div style={{ width: pct + '%', height: '100%', background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))', transition: 'width .25s ease' }} />
        </div>
        <h1 style={{ marginTop: 0 }}>{q.q}</h1>
        {q.multi && <p className="missing" style={{ marginTop: -8 }}>можно выбрать несколько</p>}
        <div className="filter-chips" style={{ gap: 10, marginTop: 'var(--space-4)' }}>
          {q.opts.map((o) => (
            <FilterChip key={o} pressed={isPicked(q, o)} onToggle={() => pick(q, o)} style={{ fontSize: '1rem', padding: '10px 16px' }}>{o}</FilterChip>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 'var(--space-8)' }}>
          {step > 0 && <Button variant="secondary" onClick={() => setStep((s) => s - 1)}>Назад</Button>}
          <Button variant="primary" disabled={!answered(q)} onClick={() => setStep((s) => s + 1)} style={{ marginLeft: 'auto' }}>
            {step === QUESTIONS.length - 1 ? 'Показать результат' : 'Дальше'}
          </Button>
        </div>
        <p className="missing" style={{ fontSize: '.8125rem', marginTop: 'var(--space-6)' }}>Тест не собирает личных данных; результат хранится только в вашем браузере.</p>
      </main>
    );
  }

  // ---- result
  const knows = ans.sure === 'Уверен(а) в направлении';
  const restart = () => { setAns({}); setStep(0); };
  const zone = (label, lvl, note) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderTop: '1px solid var(--border)' }}>
      <div><div style={{ fontWeight: 600 }}>{label}</div><div className="meta">{note}</div></div>
      <ZoneChip level={lvl} label={lvl === 'ok' ? 'опора' : lvl === 'mid' ? 'средняя' : 'зона роста'} />
    </div>
  );
  const knowsInterests = (ans.ugs || []).length > 0 && !(ans.ugs || []).includes('Ещё не знаю');
  const selfLevel = ans.stop === 'Не знаю своих сильных сторон' ? 'risk' : 'mid';
  const marketLevel = ans.stop === 'Не понимаю рынок труда' ? 'risk' : 'mid';

  return (
    <main className="container" style={{ maxWidth: 720 }}>
      <nav className="breadcrumbs"><a href="#" onClick={(e) => { e.preventDefault(); onNav('home'); }}>Главная</a> → <span aria-current="page">Результат</span></nav>
      <span className="eyebrow">Результат теста</span>
      <h1 className="tight" style={{ marginTop: 'var(--space-2)' }}>{knows ? 'Вы знаете, куда идёте' : 'Стоит сначала понять себя'}</h1>

      <div className="card" style={{ marginTop: 'var(--space-4)' }}>
        {zone('Интересы и склонности', knowsInterests ? 'ok' : 'risk', knowsInterests ? 'Есть выбранные области' : 'Область пока не выбрана')}
        {zone('Понимание себя', selfLevel, selfLevel === 'risk' ? 'Сильные стороны не названы' : 'Частичное понимание')}
        {zone('Рынок профессий', marketLevel, marketLevel === 'risk' ? 'Картина рынка не ясна' : 'Общее представление есть')}
      </div>

      {knows ? (
        <Callout intent="invite" style={{ marginTop: 'var(--space-6)' }}>
          <strong style={{ fontFamily: 'var(--display)', fontSize: '1.15rem', display: 'block', marginBottom: 4 }}>Соберём для вас список вузов</strong>
          Направление выбрано — покажем подходящие вузы с фактами: места, стоимость, общежитие.
          <div style={{ display: 'flex', gap: 12, marginTop: 12, flexWrap: 'wrap' }}>
            <Button variant="primary" onClick={() => onNav('catalog')}>Смотреть подходящие вузы →</Button>
            <Button variant="secondary" onClick={restart}>Пройти заново</Button>
          </div>
        </Callout>
      ) : (
        <Callout intent="invite" style={{ marginTop: 'var(--space-6)' }}>
          <strong style={{ fontFamily: 'var(--display)', fontSize: '1.15rem', display: 'block', marginBottom: 4 }}>Дальше нужен инструмент глубже</strong>
          Каталог отвечает на «что есть». Чтобы понять сильные стороны и подходящие профессии, нужен отдельный разбор — он оцифрует то, что тест только наметил.
          <div style={{ display: 'flex', gap: 12, marginTop: 12, flexWrap: 'wrap' }}>
            <Button variant="primary" as="a" href={window.VN_DATA.goalUrl('quiz-result')} target="_blank" rel="noopener" icon={<I.Sparkle size={18} />}>Оцифровать сильные стороны →</Button>
            <Button variant="secondary" onClick={() => onNav('catalog')}>Пока смотреть вузы</Button>
          </div>
        </Callout>
      )}
      <p className="missing" style={{ fontSize: '.8125rem', marginTop: 'var(--space-6)' }}>Переход к разбору ведёт на цель из реестра с UTM-меткой; результат теста остаётся в браузере.</p>
    </main>
  );
}
window.VNQuiz = VNQuiz;
