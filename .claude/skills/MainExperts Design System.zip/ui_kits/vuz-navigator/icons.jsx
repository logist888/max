/* Thin-line UI icons for the kit. The source platform ships NO icon library —
   it uses small inline SVGs + CSS shapes. These match that style: 24×24,
   fill none, stroke currentColor, width 2, round joins (Lucide-like geometry). */
(function () {
  const S = ({ children, size = 20, ...p }) =>
    React.createElement(
      'svg',
      { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
        strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, ...p },
      children
    );
  const P = (d) => React.createElement('path', { d });
  const L = (x1, y1, x2, y2) => React.createElement('line', { x1, y1, x2, y2 });
  const C = (cx, cy, r) => React.createElement('circle', { cx, cy, r });
  const POLY = (points, el = 'polyline') => React.createElement(el, { points });

  const Icon = (nodes) => (props) => S({ ...props, children: nodes().map((n, i) => React.cloneElement(n, { key: i })) });

  window.VNIcons = {
    Search: Icon(() => [C(11, 11, 8), L(21, 21, 16.65, 16.65)]),
    Filter: Icon(() => [POLY('22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3', 'polygon')]),
    Heart: Icon(() => [P('M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8L12 21l7.8-8.6a5.5 5.5 0 0 0 0-7.8z')]),
    Compare: Icon(() => [P('M8 3 4 7l4 4'), L(4, 7, 20, 7), P('M16 21l4-4-4-4'), L(20, 17, 4, 17)]),
    MapPin: Icon(() => [P('M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z'), C(12, 10, 3)]),
    ArrowRight: Icon(() => [L(5, 12, 19, 12), POLY('12 5 19 12 12 19')]),
    Check: Icon(() => [POLY('20 6 9 17 4 12')]),
    X: Icon(() => [L(18, 6, 6, 18), L(6, 6, 18, 18)]),
    ChevronDown: Icon(() => [POLY('6 9 12 15 18 9')]),
    Cap: Icon(() => [P('M22 10 12 5 2 10l10 5 10-5z'), P('M6 12v5c0 1 2.7 3 6 3s6-2 6-3v-5')]),
    Landmark: Icon(() => [L(3, 22, 21, 22), L(6, 18, 6, 11), L(10, 18, 10, 11), L(14, 18, 14, 11), L(18, 18, 18, 11), POLY('12 2 20 7 4 7', 'polygon')]),
    Compass: Icon(() => [C(12, 12, 10), POLY('16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88', 'polygon')]),
    Book: Icon(() => [P('M4 19.5A2.5 2.5 0 0 1 6.5 17H20'), P('M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z')]),
    Sparkle: Icon(() => [P('M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z')]),
  };
})();
