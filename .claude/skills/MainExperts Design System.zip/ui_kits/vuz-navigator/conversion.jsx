/* Conversion + trust building blocks: provenance badge, cost histogram,
   pinned goal CTA (after 40% scroll), and a once-per-session exit-intent
   that offers the quiz — never a purchase. */
(function () {
  const DS = () => window.MainExpertsDesignSystem_96585d;

  // Trust: "official export · date" — turns YMYL rigour into a selling point.
  function TrustBadge({ style }) {
    const I = window.VNIcons;
    const { meta } = window.VN_DATA;
    return React.createElement('span', {
      style: {
        display: 'inline-flex', alignItems: 'center', gap: 7, padding: '5px 12px',
        borderRadius: 999, background: 'var(--ok-soft)', color: 'var(--ok)',
        fontSize: '.8rem', fontWeight: 600, ...style,
      },
    }, React.createElement(I.Check, { size: 15 }), `Официальная выгрузка · ${meta.snapshot}`);
  }

  // Cost distribution bars above the price slider. Buckets above the current
  // ceiling dim out.
  function CostHistogram({ maxCost }) {
    const { costHistogram } = window.VN_DATA;
    const maxN = Math.max(...costHistogram.map((b) => b.n));
    const ceil = maxCost / 1000;
    return React.createElement('div', {
      style: { display: 'flex', alignItems: 'flex-end', gap: 3, height: 40, margin: '2px 0 8px' },
    }, costHistogram.map((b, i) => {
      const lo = i === 0 ? 0 : costHistogram[i - 1].to;
      const active = lo < ceil;
      return React.createElement('div', {
        key: b.to, title: `до ${b.to} тыс. ₽`,
        style: {
          flex: 1, height: `${Math.round((b.n / maxN) * 100)}%`, borderRadius: '3px 3px 0 0',
          background: active ? 'linear-gradient(135deg, var(--grad-a), var(--grad-b))' : 'var(--surface-2)',
          transition: 'background .15s ease',
        },
      });
    }));
  }

  // Pinned goal CTA — reserved (fixed) so no layout shift; reveals past 40%.
  function PinnedCTA({ placement = 'pinned', label = 'Пройти скрининг', sub = 'Понять, что подходит именно вам' }) {
    const { Button } = DS();
    const I = window.VNIcons;
    const [show, setShow] = React.useState(false);
    React.useEffect(() => {
      const on = () => {
        const h = document.documentElement;
        const denom = (h.scrollHeight - h.clientHeight) || 1;
        setShow(window.scrollY / denom > 0.4);
      };
      window.addEventListener('scroll', on, { passive: true }); on();
      return () => window.removeEventListener('scroll', on);
    }, []);
    return React.createElement('div', {
      style: {
        position: 'fixed', right: 16, bottom: 16, zIndex: 40, maxWidth: 320,
        display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px',
        background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14,
        boxShadow: 'var(--shadow-2)', transition: 'opacity .2s ease, transform .2s ease',
        opacity: show ? 1 : 0, transform: show ? 'none' : 'translateY(12px)',
        pointerEvents: show ? 'auto' : 'none',
      },
    },
      React.createElement('div', { style: { minWidth: 0 } },
        React.createElement('div', { style: { fontWeight: 600, fontSize: '.9rem' } }, label),
        React.createElement('div', { className: 'meta', style: { fontSize: '.78rem' } }, sub)),
      React.createElement(Button, {
        as: 'a', size: 'sm', href: window.VN_DATA.goalUrl(placement), target: '_blank', rel: 'noopener',
        icon: React.createElement(I.ArrowRight, { size: 16 }),
      }));
  }

  // Exit-intent (desktop): offers the quiz, once per session.
  function ExitIntent({ onQuiz }) {
    const { Button } = DS();
    const [open, setOpen] = React.useState(false);
    React.useEffect(() => {
      let done = false;
      try { done = sessionStorage.getItem('vn_exit') === '1'; } catch (e) {}
      if (done) return;
      const on = (e) => {
        if (e.clientY <= 0) {
          setOpen(true);
          try { sessionStorage.setItem('vn_exit', '1'); } catch (e2) {}
          window.removeEventListener('mouseout', on);
        }
      };
      window.addEventListener('mouseout', on);
      return () => window.removeEventListener('mouseout', on);
    }, []);
    if (!open) return null;
    const close = () => setOpen(false);
    return React.createElement('div', {
      onClick: close,
      style: { position: 'fixed', inset: 0, zIndex: 80, background: 'rgba(42,32,24,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 },
    },
      React.createElement('div', {
        onClick: (e) => e.stopPropagation(),
        style: { background: 'var(--surface)', borderRadius: 18, boxShadow: 'var(--shadow-2)', maxWidth: 440, padding: 28, position: 'relative' },
      },
        React.createElement('button', { onClick: close, 'aria-label': 'Закрыть', style: { position: 'absolute', top: 12, right: 14, background: 'none', border: 0, fontSize: '1.3rem', cursor: 'pointer', color: 'var(--text-muted)', lineHeight: 1 } }, '✕'),
        React.createElement('div', { className: 'eyebrow', style: { margin: 0 } }, 'Прежде чем уйти'),
        React.createElement('h2', { style: { margin: '6px 0 8px' } }, 'Вы знаете 7–10 профессий, а их 250 000+'),
        React.createElement('p', { style: { marginTop: 0, color: 'var(--text-muted)' } }, 'Короткий тест на 5–7 вопросов покажет, с чего начать выбор — без личных данных, результат останется в браузере.'),
        React.createElement('div', { style: { display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 8 } },
          React.createElement(Button, { variant: 'primary', onClick: () => { onQuiz && onQuiz(); close(); } }, 'Пройти тест'),
          React.createElement(Button, { variant: 'secondary', onClick: close }, 'Не сейчас'))));
  }

  window.VNConv = { TrustBadge, CostHistogram, PinnedCTA, ExitIntent };
})();
