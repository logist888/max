# ВУЗ-навигатор — UI kit

Interactive, click-through recreation of the MainExperts education SEO platform
(the "ВУЗ-навигатор"): a programmatic-SEO site that helps applicants choose a
Russian university by facts, then bridges to MainExperts' career diagnostics.

Open `index.html`. It composes the design-system primitives
(`window.MainExpertsDesignSystem_96585d`) — nothing here re-implements a Button
or a Card.

## Flow
Главная → **Каталог вузов** (faceted filters, sort tabs, rows, pager) →
**Карточка вуза** (facts, programmes by level, admission links, FAQ, the
conversion invite *after* the programmes) → **Сравнение** (up to 4, facts only)
→ **Тест** (5-question bridge quiz, two outcomes). Header nav + card clicks all
navigate.

## Files
- `index.html` — shell; loads React, the DS bundle, then the islands below.
- `data.js` — sample data in the real `OrgCard` shape (`window.VN_DATA`). Facet
  counts are plausible, not live.
- `icons.jsx` — thin-line UI glyphs (`window.VNIcons`); the source ships no icon
  set (see the README ICONOGRAPHY section).
- `Header.jsx`, `Footer.jsx` — site chrome.
- `HomeScreen.jsx` — hero (live stats + "Карта выбора" preview), how-to-choose
  cards, popular vuzy / cities / direction groups, quiz invite.
- `CatalogScreen.jsx` — real client-side faceted filtering; zero-result values
  are disabled (Booking rule — no empty list).
- `VuzScreen.jsx` — the primary university card.
- `CompareScreen.jsx` — side-by-side comparison, gaps shown explicitly.
- `QuizScreen.jsx` — `/test/` bridge; no personal data; result in the browser.

## Fidelity notes
This is a cosmetic recreation. The real platform is Astro (SSR/SSG) + PostgreSQL
+ Meilisearch; here everything is client-side React over a tiny sample set.
Repeated rows are abbreviated (6 universities standing in for 1 785). Every
value shown traces to the sample data — no invented facts, gaps rendered as
«Информация отсутствует», per the platform's data rule.
