/* Site footer: section columns + the source/date provenance line every
   data page carries (YMYL trust practice). */
function VNFooter() {
  const { meta } = window.VN_DATA;
  const col = (title, items) => (
    <div>
      <div style={{ fontWeight: 600, color: 'var(--text)', marginBottom: 8 }}>{title}</div>
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 6 }}>
        {items.map((t) => <li key={t}><a href="#" onClick={(e) => e.preventDefault()}>{t}</a></li>)}
      </ul>
    </div>
  );
  return (
    <footer className="site-footer">
      <div className="container">
        <div style={{ display: 'grid', gap: 'var(--space-8)', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', marginBottom: 'var(--space-6)' }}>
          {col('Разделы', ['Каталог вузов', 'Регионы и города', 'Направления', 'Сравнение вузов'])}
          {col('О проекте', ['О данных', 'Как выбирать вуз', 'Пройти тест', 'Частые вопросы'])}
          {col('Данные', ['Источник и актуальность', 'Что означает «пробел»', 'Правила приёма'])}
        </div>
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 'var(--space-4)', display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          <span>Источник данных: <strong style={{ color: 'var(--text)' }}>{meta.source}</strong> · выгрузка от {meta.snapshot} · приём {meta.campaign}</span>
          <span>© 2026 MainExperts. Справочные данные; проверяйте на официальных сайтах вузов.</span>
        </div>
      </div>
    </footer>
  );
}
window.VNFooter = VNFooter;
