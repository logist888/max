/* Generative university monogram — the on-brand stand-in wherever a real vuz
   logo would go. Deterministic caramel-family colour + the name's acronym.
   Drop-in slot: swap for an <img> logo later with no layout change. */
(function () {
  const PALETTE = ['#9a5a1c', '#7a4413', '#6f3f1c', '#a86a2c', '#8a5a12', '#3f7a2e'];

  function acronym(name) {
    const tokens = String(name || '').split(/\s+/).filter(Boolean);
    let best = tokens[0] || '?';
    let bestCaps = -1;
    for (const t of tokens) {
      const caps = (t.match(/\p{Lu}/gu) || []).length;
      if (caps > bestCaps) { bestCaps = caps; best = t; }
    }
    return best.replace(/[.,]/g, '').slice(0, 5);
  }

  function colorFor(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return PALETTE[h % PALETTE.length];
  }

  function VNMono({ name, size = 44, radius = 11, style }) {
    const token = acronym(name);
    const fs = size * (token.length >= 5 ? 0.24 : token.length === 4 ? 0.28 : token.length === 3 ? 0.34 : 0.42);
    return React.createElement('span', {
      'aria-hidden': true,
      style: {
        width: size, height: size, borderRadius: radius, flex: 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: colorFor(token), color: '#fff', fontFamily: 'var(--sans)',
        fontWeight: 700, fontSize: fs, letterSpacing: '-.02em', lineHeight: 1,
        boxShadow: 'inset 0 -2px 6px rgba(0,0,0,.14)', ...style,
      },
    }, token);
  }

  window.VNMono = VNMono;
  window.VNMonoAcronym = acronym;
})();
