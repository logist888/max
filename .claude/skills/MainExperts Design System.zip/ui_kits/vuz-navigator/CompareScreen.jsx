/* Comparison — up to 4 universities side by side, facts only, empty cells as
   the data-gap marker. Stored in the browser; the real page is noindex. */
function VNCompare({ onOpenVuz }) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const { Button, Missing, Badge } = DS;
  const { vuzy } = window.VN_DATA;
  const fmt = (n) => n.toLocaleString('ru-RU');
  const [ids, setIds] = React.useState(() => vuzy.slice(0, 3).map((v) => v.id));
  const chosen = ids.map((id) => vuzy.find((v) => v.id === id)).filter(Boolean);
  const remove = (id) => setIds((a) => a.filter((x) => x !== id));
  const addable = vuzy.filter((v) => !ids.includes(v.id));
  const add = () => { if (ids.length < 4 && addable[0]) setIds((a) => [...a, addable[0].id]); };

  const yn = (b) => (b ? 'да' : <Missing />);
  const rows = [
    ['Город', (v) => v.city],
    ['Уровни', (v) => v.levels.join(', ')],
    ['Направлений', (v) => fmt(v.directionsCount)],
    ['Бюджетные места', (v) => (v.budget ? 'есть' : <Missing />)],
    ['Стоимость (платно)', (v) => (v.costMin === v.costMax ? `${fmt(v.costMin)} ₽` : `${fmt(v.costMin)}–${fmt(v.costMax)} ₽`)],
    ['Общежитие', (v) => (v.dormitory ? (v.dormPlaces ? `${fmt(v.dormPlaces)} мест` : 'есть') : <Missing />)],
    ['Военная кафедра', (v) => yn(v.military)],
  ];

  return (
    <main className="container">
      <nav className="breadcrumbs"><a href="#" onClick={(e) => e.preventDefault()}>Главная</a> → <span aria-current="page">Сравнение</span></nav>
      <h1>Сравнение вузов</h1>
      <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>До четырёх вузов рядом — только факты базы. Пустая ячейка означает, что данных нет.</p>

      <div className="table-wrap" style={{ marginTop: 'var(--space-4)' }}>
        <table>
          <thead>
            <tr>
              <th style={{ minWidth: 150 }}></th>
              {chosen.map((v) => (
                <th key={v.id} style={{ minWidth: 170 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                    <window.VNMono name={v.short} size={38} radius={10} />
                    <button onClick={() => remove(v.id)} aria-label="Убрать" style={{ background: 'none', border: 0, cursor: 'pointer', color: 'var(--text-muted)', fontSize: '1rem', lineHeight: 1 }}>✕</button>
                  </div>
                  <a href="#" onClick={(e) => { e.preventDefault(); onOpenVuz(v); }} style={{ display: 'block', marginTop: 8, textTransform: 'none', letterSpacing: 0, fontSize: '.95rem', fontWeight: 600, color: 'var(--text)' }}>{v.short}</a>
                </th>
              ))}
              {ids.length < 4 && (
                <th style={{ minWidth: 150 }}>
                  <Button variant="secondary" size="sm" disabled={!addable.length} onClick={add}>+ Добавить вуз</Button>
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {rows.map(([label, get]) => (
              <tr key={label}>
                <th scope="row" style={{ color: 'var(--text-muted)' }}>{label}</th>
                {chosen.map((v) => <td key={v.id}>{get(v)}</td>)}
                {ids.length < 4 && <td></td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="missing" style={{ fontSize: '.8125rem', marginTop: 'var(--space-4)' }}>Состав сравнения хранится в браузере и в ссылке; страница — noindex.</p>
    </main>
  );
}
window.VNCompare = VNCompare;
