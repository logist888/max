/* Catalog: faceted filters (city / level / budget / dormitory / military /
   cost), sort tabs, active-chip summary, university rows, pager. Filtering is
   real client-side over the sample set; zero-result values are disabled. */
function VNCatalog({ onOpenVuz }) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const { Button, Badge, FilterChip, Tabs, Pagination } = DS;
  const { vuzy } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = (n) => n.toLocaleString('ru-RU');

  const [cities, setCities] = React.useState(() => new Set());
  const [levels, setLevels] = React.useState(() => new Set());
  const [flags, setFlags] = React.useState({ budget: false, dormitory: false, military: false });
  const [maxCost, setMaxCost] = React.useState(800000);
  const [sort, setSort] = React.useState('dirs');
  const [page, setPage] = React.useState(1);

  const cityList = React.useMemo(() => {
    const m = new Map();
    vuzy.forEach((v) => m.set(v.city, (m.get(v.city) || 0) + 1));
    return [...m.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  }, []);
  const levelList = ['Бакалавриат', 'Магистратура', 'Специалитет'];

  const toggle = (setter) => (key) => setter((prev) => {
    const next = new Set(prev); next.has(key) ? next.delete(key) : next.add(key); return next;
  });
  const toggleCity = toggle(setCities);
  const toggleLevel = toggle(setLevels);

  const matches = (v) =>
    (cities.size === 0 || cities.has(v.city)) &&
    (levels.size === 0 || v.levels.some((l) => levels.has(l))) &&
    (!flags.budget || v.budget) &&
    (!flags.dormitory || v.dormitory) &&
    (!flags.military || v.military) &&
    v.costMin <= maxCost;

  const result = vuzy.filter(matches).sort((a, b) => {
    if (sort === 'alpha') return a.short.localeCompare(b.short, 'ru');
    if (sort === 'cost') return a.costMin - b.costMin;
    return b.directionsCount - a.directionsCount;
  });

  // facet count for a would-be city selection (respects other active filters)
  const cityFacet = (name) => vuzy.filter((v) => v.city === name &&
    (levels.size === 0 || v.levels.some((l) => levels.has(l))) &&
    (!flags.budget || v.budget) && (!flags.dormitory || v.dormitory) && (!flags.military || v.military) && v.costMin <= maxCost).length;

  const activeChips = [];
  cities.forEach((c) => activeChips.push({ k: 'city:' + c, label: c, clear: () => toggleCity(c) }));
  levels.forEach((l) => activeChips.push({ k: 'lvl:' + l, label: l, clear: () => toggleLevel(l) }));
  if (flags.budget) activeChips.push({ k: 'budget', label: 'Есть бюджет', clear: () => setFlags((f) => ({ ...f, budget: false })) });
  if (flags.dormitory) activeChips.push({ k: 'dorm', label: 'Общежитие', clear: () => setFlags((f) => ({ ...f, dormitory: false })) });
  if (flags.military) activeChips.push({ k: 'mil', label: 'Военная кафедра', clear: () => setFlags((f) => ({ ...f, military: false })) });
  if (maxCost < 800000) activeChips.push({ k: 'cost', label: `до ${fmt(maxCost)} ₽`, clear: () => setMaxCost(800000) });

  const clearAll = () => { setCities(new Set()); setLevels(new Set()); setFlags({ budget: false, dormitory: false, military: false }); setMaxCost(800000); };

  const row = (v) => (
    <li key={v.id} className="card" style={{ display: 'flex', gap: 'var(--space-6)', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap' }}>
      <div style={{ display: 'flex', gap: 14, minWidth: 0, flex: '1 1 260px' }}>
        <window.VNMono name={v.short} size={46} />
        <div style={{ minWidth: 0 }}>
          <h3 style={{ margin: 0 }}><a href="#" onClick={(e) => { e.preventDefault(); onOpenVuz(v); }}>{v.short}</a></h3>
          <div className="meta" style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 4 }}><I.MapPin size={14} /> {v.city}</div>
          <div className="badges" style={{ margin: '10px 0 0' }}>
            {v.budget && <Badge tone="ok">Есть бюджет</Badge>}
            {v.dormitory && <Badge tone="neutral">Общежитие</Badge>}
            {v.military && <Badge tone="info">Военная кафедра</Badge>}
          </div>
          <div className="meta" style={{ marginTop: 8 }}>{v.levels.join(' · ')}</div>
        </div>
      </div>
      <div style={{ textAlign: 'right', flex: '0 0 auto', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
        <div style={{ fontFamily: 'var(--display)', fontSize: '1.5rem', fontWeight: 700, fontVariantNumeric: 'tabular-nums', color: 'var(--accent-strong)' }}>{v.directionsCount}</div>
        <div className="meta">направлений</div>
        <div className="meta" style={{ fontVariantNumeric: 'tabular-nums' }}>от {fmt(v.costMin)} ₽/год</div>
        <Button size="sm" style={{ marginTop: 6 }} onClick={() => onOpenVuz(v)}>Открыть карточку</Button>
      </div>
    </li>
  );

  const group = (title, children) => (
    <div className="filter-group"><div className="filter-group-title">{title}</div>{children}</div>
  );

  return (
    <main className="container">
      <nav className="breadcrumbs"><a href="#">Главная</a> → <span aria-current="page">Каталог вузов</span></nav>
      <h1>Каталог вузов</h1>
      <p style={{ color: 'var(--text-muted)', marginTop: 0, maxWidth: '60ch' }}>{fmt(window.VN_DATA.stats.vuzy)} вузов по официальной выгрузке. Отфильтруйте по городу, направлению и стоимости — пустой список получить нельзя.</p>

      <Tabs active={sort} onChange={setSort} tabs={[
        { id: 'dirs', label: 'По числу направлений' },
        { id: 'alpha', label: 'По алфавиту' },
        { id: 'cost', label: 'По стоимости' },
      ]} />

      <div className="filters">
        <div className="filters-bar">
          <span className="filters-count">{result.length} {result.length === 1 ? 'вуз' : 'вузов'} по фильтрам</span>
          {activeChips.length > 0 && <button className="filters-clear-top" onClick={clearAll}>Сбросить всё</button>}
        </div>
        <div className="filters-active">
          {activeChips.map((c) => (
            <button key={c.k} className="active-chip" onClick={c.clear}>{c.label} <span>✕</span></button>
          ))}
        </div>
        <div className="filters-panel">
          <div className="filters-groups">
            {group('Город', <div className="filter-chips">
              {cityList.map((c) => { const n = cityFacet(c.name); return (
                <FilterChip key={c.name} pressed={cities.has(c.name)} count={n} disabled={n === 0 && !cities.has(c.name)} onToggle={() => toggleCity(c.name)}>{c.name}</FilterChip>
              ); })}
            </div>)}
            {group('Уровень', <div className="filter-chips">
              {levelList.map((l) => (
                <FilterChip key={l} pressed={levels.has(l)} onToggle={() => toggleLevel(l)}>{l}</FilterChip>
              ))}
            </div>)}
            {group('Условия', <div className="filter-chips">
              <FilterChip pressed={flags.budget} onToggle={() => setFlags((f) => ({ ...f, budget: !f.budget }))}>Есть бюджет</FilterChip>
              <FilterChip pressed={flags.dormitory} onToggle={() => setFlags((f) => ({ ...f, dormitory: !f.dormitory }))}>Общежитие</FilterChip>
              <FilterChip pressed={flags.military} onToggle={() => setFlags((f) => ({ ...f, military: !f.military }))}>Военная кафедра</FilterChip>
            </div>)}
            {group('Стоимость (платно), до', <React.Fragment>
              <window.VNConv.CostHistogram maxCost={maxCost} />
              <div className="filter-range">
                <input type="range" min={138000} max={800000} step={1000} value={maxCost} onChange={(e) => setMaxCost(+e.target.value)} style={{ width: '100%', accentColor: 'var(--accent)' }} />
                <span className="filter-range-unit" style={{ fontVariantNumeric: 'tabular-nums' }}>{maxCost >= 800000 ? 'без ограничения' : `до ${fmt(maxCost)} ₽`}</span>
              </div>
            </React.Fragment>)}
          </div>
        </div>
      </div>

      {result.length === 0 ? (
        <div className="filters-empty">По выбранным фильтрам ничего не нашлось — снимите одно из условий.</div>
      ) : (
        <ul className="card-list" style={{ marginTop: 'var(--space-6)' }}>{result.map(row)}</ul>
      )}

      <Pagination page={page} pageCount={24} onPage={setPage} />
      <p className="missing" style={{ fontSize: '.8125rem' }}>Показаны примеры из демо-набора; со 2-й страницы каталог — noindex.</p>
    </main>
  );
}
window.VNCatalog = VNCatalog;
