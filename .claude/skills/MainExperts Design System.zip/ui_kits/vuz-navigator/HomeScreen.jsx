/* Home: hero with live stats + "Карта выбора" preview, how-to-choose cards,
   popular universities, cities, direction groups, and the quiz bridge. */
function VNHome({ onNav, onOpenVuz }) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const { Button, ZoneChip, Card, Callout } = DS;
  const { stats, cities, ugs, vuzy, meta } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = (n) => n.toLocaleString('ru-RU');
  const stop = (fn) => (e) => { e.preventDefault(); fn && fn(); };

  return (
    <main className="container">
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-copy">
            <h1>Выбор вуза без догадок</h1>
            <p>Все вузы России, направления и стоимость обучения — по официальной выгрузке. Сначала факты целиком, а потом поможем понять, что подходит именно вам.</p>
            <div className="actions">
              <Button as="a" href="#" variant="primary" icon={<I.Landmark size={18} />} onClick={stop(() => onNav('catalog'))}>Смотреть {fmt(stats.vuzy)} вузов</Button>
              <Button as="a" href="#" variant="secondary" icon={<I.Compass size={18} />} onClick={stop(() => onNav('test'))}>Пройти тест</Button>
            </div>
            <div className="chips">
              <span className="chip"><span className="num">{fmt(stats.goroda)}</span> городов</span>
              <span className="chip"><span className="num">{fmt(stats.napravleniya)}</span> направлений</span>
              <span className="chip"><span className="num">{fmt(stats.stranicy)}</span> страниц данных</span>
            </div>
            <div className="prov">Источник данных: <span className="src">{meta.source}</span> выгрузка от {meta.snapshot} · приём {meta.campaign}</div>
            <div style={{ marginTop: 12 }}><window.VNConv.TrustBadge style={{ background: 'rgba(255,255,255,.16)', color: '#fff' }} /></div>
          </div>
          <div className="reveal in" style={{ background: 'var(--surface)', color: 'var(--text)', borderRadius: 18, padding: 20, boxShadow: 'var(--shadow-2)' }}>
            <div className="eyebrow" style={{ margin: 0 }}>Карта выбора</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '6px 0 10px' }}>
              <strong style={{ fontFamily: 'var(--display)', fontSize: '1.15rem' }}>Профиль заполнен на 40%</strong>
              <ZoneChip level="mid" count={3} label="из 6 зон" />
            </div>
            <div style={{ height: 8, borderRadius: 999, background: 'var(--surface-2)', overflow: 'hidden', marginBottom: 14 }}>
              <div style={{ width: '40%', height: '100%', background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))' }} />
            </div>
            {[['Интересы и склонности', 'ok', 'сильная сторона'], ['Рынок профессий', 'risk', 'зона риска'], ['Понимание себя', 'mid', 'средняя зона']].map(([k, lvl, lab]) => (
              <div key={k} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid var(--border)' }}>
                <span style={{ fontSize: '.92rem' }}>{k}</span>
                <ZoneChip level={lvl} label={lab} />
              </div>
            ))}
            <Button variant="primary" size="sm" style={{ width: '100%', marginTop: 14 }} onClick={() => onNav('test')}>Собрать мою карту →</Button>
          </div>
        </div>
      </section>

      <div className="eyebrow">Как это работает</div>
      <h2 className="tight" style={{ marginTop: 'var(--space-2)' }}>Три шага к решению</h2>
      <ul className="card-list grid-3">
        <li><Card icon={<I.Landmark />} eyebrow="Шаг 1" title="Найдите вузы по фактам">Фильтруйте по городу, направлению, бюджету и стоимости. Пустой список получить нельзя.</Card></li>
        <li><Card icon={<I.Compare />} eyebrow="Шаг 2" title="Сравните варианты">До четырёх вузов рядом: направления, места, вилка цен, общежитие — только факты базы.</Card></li>
        <li><Card icon={<I.Compass />} eyebrow="Шаг 3" title="Поймите, что подходит">Факты не говорят, что подходит именно вам. Короткий тест наметит следующий шаг.</Card></li>
      </ul>

      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12 }}>
        <h2>Популярные вузы</h2>
        <a href="#" onClick={stop(() => onNav('catalog'))}>Весь каталог →</a>
      </div>
      <ul className="card-list grid-3">
        {vuzy.slice(0, 6).map((v) => (
          <li key={v.id}>
            <Card title={v.short} href="#" icon={<window.VNMono name={v.short} size={40} radius={11} />} meta={[v.city, `${v.directionsCount} направлений`, `от ${fmt(v.costMin)} ₽ в год`]}
              onClick={stop(() => onOpenVuz(v))} style={{ cursor: 'pointer' }}>
              <div className="badges" style={{ margin: '10px 0 0' }}>
                {v.budget && <DS.Badge tone="ok">Бюджет</DS.Badge>}
                {v.dormitory && <DS.Badge tone="neutral">Общежитие</DS.Badge>}
              </div>
            </Card>
          </li>
        ))}
      </ul>

      <h2>Города</h2>
      <ul className="card-list grid-4">
        {cities.slice(0, 8).map((c) => (
          <li key={c.slug}><Card title={c.name} href="#" meta={[`${c.count} вузов`]} onClick={stop(() => onNav('catalog'))} style={{ cursor: 'pointer' }} /></li>
        ))}
      </ul>

      <h2>Направления по группам</h2>
      <ul className="card-list grid-3">
        {ugs.map((g) => (
          <li key={g.code}><Card title={`${g.code} · ${g.name}`} href="#" meta={[`${g.dirs} направлений`, `${fmt(g.vuzy)} вузов`]} onClick={stop(() => onNav('directions'))} style={{ cursor: 'pointer' }} /></li>
        ))}
      </ul>

      <Callout intent="invite" style={{ marginTop: 'var(--space-8)' }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <div style={{ maxWidth: '46ch' }}>
            <strong style={{ fontFamily: 'var(--display)', fontSize: '1.2rem', display: 'block', marginBottom: 4 }}>Знаете 7–10 профессий, а их больше 250 000</strong>
            Факты не говорят, что подходит именно вам. Тест на 5–7 вопросов наметит следующий шаг — без личных данных.
          </div>
          <Button variant="primary" onClick={() => onNav('test')}>Пройти тест</Button>
        </div>
      </Callout>
    </main>
  );
}
window.VNHome = VNHome;
