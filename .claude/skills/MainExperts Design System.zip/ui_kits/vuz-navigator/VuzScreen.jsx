/* University card — the platform's primary page. Header + fact badges, fact
   strip, programmes folded by level, admission links, FAQ from facts, the
   conversion invite AFTER the programmes block, and "similar" nearby. */
function VNVuz({ vuz, onNav, onOpenVuz }) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const { Badge, FactList, LevelGroup, DataTable, Callout, Button, Missing, Breadcrumbs, Card } = DS;
  const { vuzy, meta } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = (n) => n.toLocaleString('ru-RU');
  const costPhrase = (a, b) => (a === b ? `${fmt(a)} ₽ в год` : `от ${fmt(a)} до ${fmt(b)} ₽ в год`);

  const dirRow = (d) => {
    const budget = d.offers.filter((o) => o.placeType === 'бюджет').reduce((s, o) => s + (o.places || 0), 0);
    const paid = d.offers.filter((o) => o.placeType === 'платно').reduce((s, o) => s + (o.places || 0), 0);
    const paidOffer = d.offers.find((o) => o.placeType === 'платно' && o.cost != null);
    const forms = [...new Set(d.offers.map((o) => o.form))].join(', ');
    return {
      dir: <span><strong style={{ fontVariantNumeric: 'tabular-nums' }}>{d.okso}</strong> {d.name}</span>,
      form: forms,
      budget: budget || null,
      paid: paid || null,
      cost: paidOffer ? `${fmt(paidOffer.cost)} ₽` : null,
      _start: true,
    };
  };

  const faq = [];
  faq.push({ q: `Есть ли бюджетные места в «${vuz.short}»?`, a: vuz.budget ? 'Да, в выгрузке заявлены бюджетные места (основные места в рамках КЦП и квоты).' : `В выгрузке от ${meta.snapshot} бюджетные места не указаны.` });
  faq.push({ q: 'Сколько стоит платное обучение?', a: `По данным выгрузки — ${costPhrase(vuz.costMin, vuz.costMax)}.` });
  faq.push({ q: 'Есть ли общежитие?', a: vuz.dormitory ? (vuz.dormPlaces ? `Да. Мест в общежитии по данным выгрузки: ${fmt(vuz.dormPlaces)}.` : 'Да, общежитие заявлено. Число мест в выгрузке не указано.') : `В выгрузке от ${meta.snapshot} общежитие не указано.` });
  if (vuz.military) faq.push({ q: 'Есть ли военная кафедра?', a: 'Да, военный учебный центр заявлен в данных.' });

  const similar = vuzy.filter((v) => v.id !== vuz.id && (v.city === vuz.city || v.region === vuz.region)).slice(0, 3);
  const similarFallback = similar.length ? similar : vuzy.filter((v) => v.id !== vuz.id).slice(0, 3);

  const cols = [
    { key: 'dir', label: 'Направление' },
    { key: 'form', label: 'Форма' },
    { key: 'budget', label: 'Бюджет', num: true },
    { key: 'paid', label: 'Платно', num: true },
    { key: 'cost', label: 'Стоимость', num: true },
  ];

  return (
    <main className="container">
      <Breadcrumbs items={[{ name: 'Главная', href: '#' }, { name: vuz.city, href: '#' }, { name: vuz.short }]} />
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
        <window.VNMono name={vuz.short} size={64} radius={16} style={{ marginTop: 'var(--space-6)' }} />
        <div style={{ minWidth: 0 }}>
          <h1 style={{ marginBottom: 4 }}>{vuz.short}</h1>
          <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>{vuz.full}</p>
        </div>
      </div>
      <div className="badges">
        {vuz.budget && <Badge tone="ok">Есть бюджетные места</Badge>}
        {vuz.dormitory && <Badge tone="neutral">Общежитие</Badge>}
        {vuz.military && <Badge tone="info">Военная кафедра</Badge>}
        <window.VNConv.TrustBadge style={{ marginLeft: 4 }} />
      </div>

      <FactList items={[
        { label: 'Направлений', value: fmt(vuz.directionsCount) },
        { label: 'Уровни', value: vuz.levels.join(', ') },
        { label: 'Стоимость (платно)', value: costPhrase(vuz.costMin, vuz.costMax) },
        { label: 'Мест в общежитии', value: vuz.dormPlaces ? fmt(vuz.dormPlaces) : null },
        { label: 'Телефон', value: vuz.phones[0] },
        { label: 'Сайт', value: vuz.sites[0] ? <a href="#" onClick={(e) => e.preventDefault()}>{vuz.sites[0]}</a> : null },
      ]} />

      <h2>Программы обучения</h2>
      {vuz.programs.map((p) => (
        <LevelGroup key={p.level} title={p.level} summary={`${p.dirs.length} ${p.dirs.length === 1 ? 'направление' : 'направления'}`} defaultOpen={p === vuz.programs[0]}>
          <DataTable columns={cols} rows={p.dirs.map(dirRow)} />
        </LevelGroup>
      ))}

      <Callout intent="invite">
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <div style={{ maxWidth: '48ch' }}>
            <strong style={{ fontFamily: 'var(--display)', fontSize: '1.15rem', display: 'block', marginBottom: 4 }}>Факты собраны. Но подходит ли вам «{vuz.short}»?</strong>
            База отвечает на «что есть». На «что подходит именно вам» — короткий тест на 5–7 вопросов, без личных данных.
          </div>
          <Button variant="primary" onClick={() => onNav('test')}>Пройти тест →</Button>
        </div>
      </Callout>

      <h2>Приёмная кампания {meta.campaign}</h2>
      <div className="badges">
        {Object.keys(vuz.usefulLinks).map((k) => (
          <a key={k} className="badge" href="#" onClick={(e) => e.preventDefault()} style={{ textDecoration: 'none' }}>{k} →</a>
        ))}
      </div>

      <h2>Частые вопросы</h2>
      <dl className="faq">
        {faq.map((f) => (<React.Fragment key={f.q}><dt>{f.q}</dt><dd>{f.a}</dd></React.Fragment>))}
      </dl>

      <h2>Рядом и похоже</h2>
      <ul className="card-list grid-3">
        {similarFallback.map((v) => (
          <li key={v.id}><Card title={v.short} href="#" icon={<window.VNMono name={v.short} size={40} radius={11} />} meta={[v.city, `${v.directionsCount} направлений`, `от ${fmt(v.costMin)} ₽ в год`]} onClick={(e) => { e.preventDefault(); onOpenVuz(v); }} style={{ cursor: 'pointer' }} /></li>
        ))}
      </ul>

      <p className="missing" style={{ fontSize: '.8125rem', borderTop: '1px solid var(--border)', paddingTop: 'var(--space-4)', fontStyle: 'normal', color: 'var(--text-muted)' }}>
        Источник: <strong style={{ color: 'var(--text)' }}>{meta.source}</strong> · выгрузка от {meta.snapshot} · приём {meta.campaign}. Справочные данные; проверяйте на официальном сайте вуза.
      </p>
      <window.VNConv.PinnedCTA placement="vuz-pinned" />
    </main>
  );
}
window.VNVuz = VNVuz;
