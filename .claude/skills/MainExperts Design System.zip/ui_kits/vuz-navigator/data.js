/* Sample data for the ВУЗ-навигатор UI kit. Illustrative values in the real
   OrgCard shape (see app/src/lib/data.ts). Facet counts are plausible, not live.
   window global so Babel islands can read it. */
window.VN_DATA = (function () {
  const meta = { snapshot: '10.07.2026', campaign: '2026/27', source: 'ВУЗ-навигатор' };

  const stats = {
    vuzy: 1785, goroda: 358, regiony: 87,
    napravleniya: 894, ugs: 57, stranicy: 9440,
    medianaPaid: 190000, budgetShare: 78,
  };

  const cities = [
    { slug: 'moskva', name: 'Москва', count: 336 },
    { slug: 'sankt-peterburg', name: 'Санкт-Петербург', count: 78 },
    { slug: 'ekaterinburg', name: 'Екатеринбург', count: 28 },
    { slug: 'kazan', name: 'Казань', count: 24 },
    { slug: 'novosibirsk', name: 'Новосибирск', count: 21 },
    { slug: 'nizhniy-novgorod', name: 'Нижний Новгород', count: 19 },
    { slug: 'rostov-na-donu', name: 'Ростов-на-Дону', count: 17 },
    { slug: 'samara', name: 'Самара', count: 15 },
  ];

  const ugs = [
    { code: '09', name: 'Информатика и вычислительная техника', dirs: 11, vuzy: 612 },
    { code: '38', name: 'Экономика и управление', dirs: 19, vuzy: 987 },
    { code: '40', name: 'Юриспруденция', dirs: 4, vuzy: 741 },
    { code: '01', name: 'Математика и механика', dirs: 8, vuzy: 214 },
    { code: '03', name: 'Физика и астрономия', dirs: 5, vuzy: 156 },
    { code: '45', name: 'Языкознание и литературоведение', dirs: 7, vuzy: 298 },
  ];

  // Detailed university cards.
  const vuzy = [
    {
      id: '1147', slug: 'mgu-1147', short: 'МГУ им. М. В. Ломоносова',
      full: 'Московский государственный университет имени М. В. Ломоносова',
      city: 'Москва', citySlug: 'moskva', region: 'Москва',
      directionsCount: 58, costMin: 391800, costMax: 495000,
      budget: true, dormitory: true, dormPlaces: 6000, military: true,
      phones: ['+7 495 939-10-00'], sites: ['msu.ru'],
      levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '01.03.02', name: 'Прикладная математика и информатика', ugs: '01', offers: [{ form: 'очная', placeType: 'бюджет', places: 120, cost: null }, { form: 'очная', placeType: 'платно', places: 45, cost: 391800 }] },
          { okso: '03.03.02', name: 'Физика', ugs: '03', offers: [{ form: 'очная', placeType: 'бюджет', places: 95, cost: null }, { form: 'очная', placeType: 'платно', places: 20, cost: 391800 }] },
          { okso: '38.03.01', name: 'Экономика', ugs: '38', offers: [{ form: 'очная', placeType: 'платно', places: 60, cost: 495000 }] },
        ] },
        { level: 'Магистратура', dirs: [
          { okso: '01.04.02', name: 'Прикладная математика и информатика', ugs: '01', offers: [{ form: 'очная', placeType: 'бюджет', places: 80, cost: null }, { form: 'очная', placeType: 'платно', places: 15, cost: 410000 }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#', 'Перечень олимпиад': '#', 'Стоимость обучения': '#' },
    },
    {
      id: '2032', slug: 'itmo-2032', short: 'Университет ИТМО',
      full: 'Национальный исследовательский университет ИТМО',
      city: 'Санкт-Петербург', citySlug: 'sankt-peterburg', region: 'Санкт-Петербург',
      directionsCount: 32, costMin: 284000, costMax: 372000,
      budget: true, dormitory: true, dormPlaces: 3200, military: false,
      phones: ['+7 812 480-00-00'], sites: ['itmo.ru'],
      levels: ['Бакалавриат', 'Магистратура'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '09.03.01', name: 'Информатика и вычислительная техника', ugs: '09', offers: [{ form: 'очная', placeType: 'бюджет', places: 210, cost: null }, { form: 'очная', placeType: 'платно', places: 90, cost: 372000 }] },
          { okso: '09.03.04', name: 'Программная инженерия', ugs: '09', offers: [{ form: 'очная', placeType: 'бюджет', places: 120, cost: null }, { form: 'очная', placeType: 'платно', places: 60, cost: 372000 }] },
        ] },
        { level: 'Магистратура', dirs: [
          { okso: '09.04.01', name: 'Информатика и вычислительная техника', ugs: '09', offers: [{ form: 'очная', placeType: 'бюджет', places: 140, cost: null }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#', 'Достижения': '#' },
    },
    {
      id: '0891', slug: 'spbgu-0891', short: 'СПбГУ',
      full: 'Санкт-Петербургский государственный университет',
      city: 'Санкт-Петербург', citySlug: 'sankt-peterburg', region: 'Санкт-Петербург',
      directionsCount: 54, costMin: 268000, costMax: 448000,
      budget: true, dormitory: true, dormPlaces: null, military: true,
      phones: ['+7 812 328-20-00'], sites: ['spbu.ru'],
      levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '40.03.01', name: 'Юриспруденция', ugs: '40', offers: [{ form: 'очная', placeType: 'бюджет', places: 100, cost: null }, { form: 'очная', placeType: 'платно', places: 180, cost: 448000 }] },
          { okso: '45.03.01', name: 'Филология', ugs: '45', offers: [{ form: 'очная', placeType: 'бюджет', places: 75, cost: null }, { form: 'очно-заочная', placeType: 'платно', places: 40, cost: 268000 }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#', 'Апелляции': '#', 'Олимпиады': '#' },
    },
    {
      id: '3310', slug: 'mfti-3310', short: 'МФТИ',
      full: 'Московский физико-технический институт (национальный исследовательский университет)',
      city: 'Долгопрудный', citySlug: 'dolgoprudnyy', region: 'Московская область',
      directionsCount: 16, costMin: 396000, costMax: 396000,
      budget: true, dormitory: true, dormPlaces: 4100, military: true,
      phones: ['+7 495 408-45-54'], sites: ['mipt.ru'],
      levels: ['Бакалавриат', 'Магистратура'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '03.03.01', name: 'Прикладные математика и физика', ugs: '03', offers: [{ form: 'очная', placeType: 'бюджет', places: 900, cost: null }, { form: 'очная', placeType: 'платно', places: 120, cost: 396000 }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#' },
    },
    {
      id: '1904', slug: 'hse-1904', short: 'НИУ ВШЭ',
      full: 'Национальный исследовательский университет «Высшая школа экономики»',
      city: 'Москва', citySlug: 'moskva', region: 'Москва',
      directionsCount: 63, costMin: 390000, costMax: 770000,
      budget: true, dormitory: true, dormPlaces: 5400, military: false,
      phones: ['+7 495 771-32-42'], sites: ['hse.ru'],
      levels: ['Бакалавриат', 'Магистратура'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '38.03.01', name: 'Экономика', ugs: '38', offers: [{ form: 'очная', placeType: 'бюджет', places: 60, cost: null }, { form: 'очная', placeType: 'платно', places: 300, cost: 770000 }] },
          { okso: '09.03.04', name: 'Программная инженерия', ugs: '09', offers: [{ form: 'очная', placeType: 'бюджет', places: 80, cost: null }, { form: 'очная', placeType: 'платно', places: 120, cost: 610000 }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#', 'Индивидуальные достижения': '#' },
    },
    {
      id: '2571', slug: 'kfu-2571', short: 'КФУ',
      full: 'Казанский (Приволжский) федеральный университет',
      city: 'Казань', citySlug: 'kazan', region: 'Республика Татарстан',
      directionsCount: 71, costMin: 138000, costMax: 226000,
      budget: true, dormitory: true, dormPlaces: 8100, military: true,
      phones: ['+7 843 233-71-09'], sites: ['kpfu.ru'],
      levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
      programs: [
        { level: 'Бакалавриат', dirs: [
          { okso: '38.03.01', name: 'Экономика', ugs: '38', offers: [{ form: 'очная', placeType: 'бюджет', places: 120, cost: null }, { form: 'заочная', placeType: 'платно', places: 200, cost: 138000 }] },
          { okso: '40.03.01', name: 'Юриспруденция', ugs: '40', offers: [{ form: 'очная', placeType: 'бюджет', places: 90, cost: null }, { form: 'очная', placeType: 'платно', places: 150, cost: 226000 }] },
        ] },
      ],
      usefulLinks: { 'Правила приёма': '#', 'Общежития': '#' },
    },
  ];

  // Active conversion goal (registry, single URL) — dev screening for now.
  const goal = { base: 'https://dev.mainexperts.online/screening' };
  function goalUrl(placement) {
    const u = new URL(goal.base);
    u.searchParams.set('utm_source', 'vuznavigator');
    u.searchParams.set('utm_medium', placement || 'cta');
    u.searchParams.set('utm_campaign', 'screening');
    return u.toString();
  }

  // Illustrative paid-tuition distribution (median 190k, quartiles 158–270k).
  // Each bucket: upper bound in thousands ₽/year + count.
  const costHistogram = [
    { to: 100, n: 3 }, { to: 150, n: 9 }, { to: 190, n: 16 }, { to: 230, n: 14 },
    { to: 270, n: 11 }, { to: 320, n: 7 }, { to: 400, n: 5 }, { to: 520, n: 3 }, { to: 800, n: 2 },
  ];

  return { meta, stats, cities, ugs, vuzy, goal, goalUrl, costHistogram };
})();
