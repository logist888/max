---
name: mainexperts-design
description: Use this skill to generate well-branded interfaces and assets for MainExperts (the «ВУЗ-навигатор» education platform), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick map
- `README.md` — the full design guide: sources, content voice, visual foundations, iconography, and the file index. **Read this first.**
- `styles.css` — the one stylesheet to link; `@import`s the tokens, fonts, base and component CSS.
- `tokens/` + `base.css` + `components.css` — foundations and the platform's CSS class vocabulary.
- `assets/` — real logo, favicon and the self-hosted Inter + Lora webfonts (cyr + lat).
- `guidelines/` — specimen cards for colours, type, spacing and brand.
- `components/` — React primitives (core / navigation / data). Each has a `.prompt.md`.
- `ui_kits/vuz-navigator/` — interactive recreation of the product's core screens.

## Non-negotiables
- Russian, professional, no anglicisms, no emoji. Voice: "помогает решить, а не продаёт".
- Show data gaps explicitly as «Информация отсутствует» — never fake a value.
- Every data view carries a source + date line. Numbers as `190 000 ₽`, counts pluralised.
- Two fonts only (Lora headings, Inter body/UI); one caramel accent; at most 1–2 background colours.
- Never publish diagnostic method names (Big Five / RIASEC → working names only).
