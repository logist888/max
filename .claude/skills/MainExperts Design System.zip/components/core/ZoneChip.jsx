import React from 'react';

/**
 * Semantic zone chip — the shared visual language with the MainExperts
 * screening product ("N зон риска из 6"). A colour-coded count/label:
 * risk (red), mid (amber/warn), ok (green).
 */
export function ZoneChip({ level = 'mid', count, label, className = '', children, ...rest }) {
  const cls = ['zone-chip', `zone-chip--${level}`, className].filter(Boolean).join(' ');
  return (
    <span className={cls} {...rest}>
      {count != null && <strong>{count}</strong>}
      {label ?? children}
    </span>
  );
}
