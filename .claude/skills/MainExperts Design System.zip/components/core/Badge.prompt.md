One-line: a small pill stating a single TRUE fact about an entity (budget places, dormitory, military department) — never rendered for an absent flag.

```jsx
<div className="badges">
  <Badge tone="ok">Есть бюджетные места</Badge>
  <Badge tone="neutral">Общежитие</Badge>
  <Badge tone="info">Военная кафедра</Badge>
</div>
```

Tones: `ok` (green, positive), `info` (caramel), `neutral` (surface-2). Wrap a group in a `.badges` flex row. Data rule: absence of a flag is silence, not a red badge.
