import React from 'react';

/**
 * The platform's signature "data gap" marker. A missing fact is shown
 * explicitly and italic — never hidden and never faked as a zero.
 */
export function Missing({ children = 'Информация отсутствует', className = '', ...rest }) {
  return (
    <span className={['missing', className].filter(Boolean).join(' ')} {...rest}>
      {children}
    </span>
  );
}
