One-line: the signature explicit data-gap marker — muted italic "Информация отсутствует" that stands in wherever a fact is absent.

```jsx
<span className="label">Общежитие</span>
{card.dormPlaces ?? <Missing />}
```

Core data rule of the whole platform: a gap is shown, not hidden, and never rendered as 0 ₽ or a false negative. Use inside fact tiles, table cells, and comparison rows.
