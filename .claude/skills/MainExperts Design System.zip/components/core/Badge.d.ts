import type { ReactNode, HTMLAttributes } from 'react';

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  /** neutral = surface-2 chip; ok = green (positive fact); info = caramel. Default neutral. */
  tone?: 'neutral' | 'ok' | 'info';
  className?: string;
  children?: ReactNode;
}

export declare function Badge(props: BadgeProps): JSX.Element;
