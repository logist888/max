import type { ReactNode, HTMLAttributes } from 'react';

export interface MissingProps extends HTMLAttributes<HTMLSpanElement> {
  /** Override the default "Информация отсутствует" text. */
  children?: ReactNode;
  className?: string;
}

export declare function Missing(props: MissingProps): JSX.Element;
