import React from 'react';

/**
 * Boxed callout. Two intents:
 *  - notice: neutral/caution note (amber left border) — e.g. a data caveat.
 *  - invite: conversion value-prop (accent left border) — the "next step"
 *    bridge to diagnostics. Accent, NOT a warning.
 */
export function Callout({ intent = 'notice', className = '', children, ...rest }) {
  const cls = [intent === 'invite' ? 'invite' : 'notice', className].filter(Boolean).join(' ');
  return (
    <div className={cls} {...rest}>
      {children}
    </div>
  );
}
