import React from 'react';

/**
 * Primary action control. Caramel gradient pill (primary) or outlined surface
 * (secondary). Renders as <button> or <a>. On a dark hero, .hero context flips
 * primary to a light fill automatically via CSS.
 */
export function Button({
  variant = 'primary',
  size,
  as = 'button',
  icon,
  disabled = false,
  className = '',
  children,
  ...rest
}) {
  const Tag = as;
  const cls = ['btn', `btn-${variant}`, size === 'sm' && 'btn-sm', className]
    .filter(Boolean)
    .join(' ');
  const extra =
    Tag === 'a'
      ? { 'aria-disabled': disabled || undefined }
      : { disabled };
  return (
    <Tag className={cls} {...extra} {...rest}>
      {icon}
      {children}
    </Tag>
  );
}
