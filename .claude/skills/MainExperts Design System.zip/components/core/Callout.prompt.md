One-line: a left-bordered boxed callout — `notice` for a data caveat (amber), `invite` for the conversion bridge to diagnostics (accent).

```jsx
<Callout intent="notice">Данные приведены по выгрузке от 10.07.2026.</Callout>
<Callout intent="invite">
  Факты не говорят, что подходит именно тебе. <a href="/test/">Пройти тест →</a>
</Callout>
```

`invite` is an accent value-prop, never styled as an alert. Keep the CTA phrased as the next decision step, not a sell (platform principle: "помогает решить, а не продаёт").
