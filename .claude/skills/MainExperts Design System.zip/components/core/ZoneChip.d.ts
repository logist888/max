import type { ReactNode, HTMLAttributes } from 'react';

export interface ZoneChipProps extends HTMLAttributes<HTMLSpanElement> {
  /** risk = red, mid = amber, ok = green. Default mid. */
  level?: 'risk' | 'mid' | 'ok';
  /** Optional leading number (tabular figures) — e.g. count of risk zones. */
  count?: number;
  /** Chip text; alternatively pass children. */
  label?: ReactNode;
  className?: string;
  children?: ReactNode;
}

export declare function ZoneChip(props: ZoneChipProps): JSX.Element;
