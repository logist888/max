import React from 'react';

/**
 * Small rounded label for a boolean fact ("Есть бюджетные места",
 * "Общежитие"). Only ever states a TRUE flag — an absent flag is never
 * rendered as a negative badge (platform data rule).
 */
export function Badge({ tone = 'neutral', className = '', children, ...rest }) {
  const cls = ['badge', tone === 'ok' && 'badge--ok', tone === 'info' && 'badge--info', className]
    .filter(Boolean)
    .join(' ');
  return (
    <span className={cls} {...rest}>
      {children}
    </span>
  );
}
