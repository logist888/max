One-line: the platform's primary action control — a caramel gradient pill (`primary`) or an outlined surface button (`secondary`), rendered as `<button>` or `<a>`.

```jsx
<Button variant="primary" as="a" href="/test/">Пройти тест</Button>
<Button variant="secondary" size="sm" icon={<HeartIcon/>}>В избранное</Button>
```

Variants: `primary` (gradient, use once per view as the main CTA), `secondary` (outline, for lower-priority actions). `size="sm"` for header/toolbar density. Inside a `.hero`, `primary` auto-switches to a light fill for contrast — don't override. Full-pill radius (999px) is intentional and applies at every size.
