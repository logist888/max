One-line: a colour-coded semantic chip (risk / mid / ok) that carries the screening product's "zones of risk" language into the navigator — used for quiz results and risk read-outs.

```jsx
<ZoneChip level="risk" count={4} label="зоны риска" />
<ZoneChip level="ok" label="сильная сторона" />
```

Levels map to the semantic tokens: `risk` (--risk), `mid` (--warn), `ok` (--ok), each on its soft background. `count` renders bold with tabular figures. Keep the language factual and non-alarmist per the platform tone.
