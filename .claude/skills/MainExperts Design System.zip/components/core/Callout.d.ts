import type { ReactNode, HTMLAttributes } from 'react';

export interface CalloutProps extends HTMLAttributes<HTMLDivElement> {
  /** notice = amber caution note; invite = accent conversion value-prop. Default notice. */
  intent?: 'notice' | 'invite';
  className?: string;
  children?: ReactNode;
}

export declare function Callout(props: CalloutProps): JSX.Element;
