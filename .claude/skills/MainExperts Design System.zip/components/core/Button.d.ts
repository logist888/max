import type { ReactNode, HTMLAttributes } from 'react';

export interface ButtonProps extends HTMLAttributes<HTMLElement> {
  /** primary = caramel gradient pill; secondary = outline on surface. Default primary. */
  variant?: 'primary' | 'secondary';
  /** 'sm' for the compact 36px height used in dense toolbars. */
  size?: 'sm';
  /** Element to render. Default 'button'. Use 'a' for navigation. */
  as?: 'button' | 'a';
  /** Optional leading inline-SVG icon. */
  icon?: ReactNode;
  /** Disabled state (dims + blocks pointer). */
  disabled?: boolean;
  className?: string;
  children?: ReactNode;
}

export declare function Button(props: ButtonProps): JSX.Element;
