import type { ReactNode, HTMLAttributes } from 'react';

export interface LevelGroupProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
  /** Group heading, e.g. "Бакалавриат". */
  title: ReactNode;
  /** Right-aligned muted summary, e.g. "24 направления". */
  summary?: ReactNode;
  /** Open by default (uncontrolled). */
  defaultOpen?: boolean;
  /** Controlled open state (pair with onToggle). */
  open?: boolean;
  onToggle?: (e: React.SyntheticEvent<HTMLDetailsElement>) => void;
  className?: string;
  children?: ReactNode;
}

export declare function LevelGroup(props: LevelGroupProps): JSX.Element;
