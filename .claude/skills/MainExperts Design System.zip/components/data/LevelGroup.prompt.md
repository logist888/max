One-line: a collapsible `<details>` group used to fold the programmes block of a university card by education level (default-collapsed on 200+ positions).

```jsx
<LevelGroup title="Бакалавриат" summary="24 направления" defaultOpen>
  <DataTable columns={cols} rows={rows} />
</LevelGroup>
```

Built on native `<details>` — works without JS. Chevron rotates on open. On big cards, collapse groups by default (leave the first open).
