One-line: the fact strip near the top of an entity card — a responsive grid of labelled tiles, each showing a fact or the explicit data-gap marker.

```jsx
<FactList items={[
  { label: 'Направлений', value: '58' },
  { label: 'Стоимость (платно)', value: 'от 200 000 ₽ в год' },
  { label: 'Мест в общежитии', value: null },   // → «Информация отсутствует»
  { label: 'Контакты', value: '+7 495 …' },
]} />
```

Labels are uppercase muted. Never pass 0 or a placeholder for an unknown value — pass null and let the marker show.
