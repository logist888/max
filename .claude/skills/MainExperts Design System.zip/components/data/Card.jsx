import React from 'react';

/**
 * Hover-lift content card. Used for entity tiles (a university, a city, a
 * direction) in a `.card-list` grid, and for "how to choose" question cards
 * (pass `icon` to get the rounded icon plate + `eyebrow`).
 */
export function Card({ title, href, eyebrow, icon, meta = [], className = '', children, ...rest }) {
  return (
    <div className={['card', className].filter(Boolean).join(' ')} {...rest}>
      {icon && <span className="qic">{icon}</span>}
      {eyebrow && <div className="eyebrow" style={{ margin: 0 }}>{eyebrow}</div>}
      {title && (
        <h3>{href ? <a href={href}>{title}</a> : title}</h3>
      )}
      {meta.map((m, i) => (
        <div className="meta" key={i}>{m}</div>
      ))}
      {children}
    </div>
  );
}
