import React from 'react';

/**
 * Collapsible group of programmes by level (Бакалавриат, Магистратура, …).
 * The chevron and open/close animation come from the .level-group CSS.
 */
export function LevelGroup({ title, summary, defaultOpen = false, open, onToggle, className = '', children, ...rest }) {
  const controlled = open != null;
  return (
    <details
      className={['level-group', className].filter(Boolean).join(' ')}
      {...(controlled ? { open } : { open: defaultOpen })}
      onToggle={onToggle}
      {...rest}
    >
      <summary>
        <span>{title}</span>
        {summary != null && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>{summary}</span>}
      </summary>
      <div>{children}</div>
    </details>
  );
}
