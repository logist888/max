import React from 'react';
import { Missing } from '../core/Missing.jsx';

/**
 * Horizontally-scrollable data table. Pass columns + rows for the common case
 * (numeric columns right-align with tabular figures; empty cells show the
 * data-gap marker), or pass children for full manual control.
 */
export function DataTable({ columns, rows = [], className = '', children, ...rest }) {
  return (
    <div className="table-wrap">
      <table className={className} {...rest}>
        {columns && (
          <>
            <thead>
              <tr>
                {columns.map((c) => (
                  <th key={c.key} style={c.num ? { textAlign: 'right' } : undefined}>{c.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className={r._start ? 'dir-start' : undefined}>
                  {columns.map((c) => {
                    const v = r[c.key];
                    const empty = v == null || v === '';
                    return (
                      <td key={c.key} className={c.num ? 'num' : undefined}>
                        {empty ? <Missing /> : v}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </>
        )}
        {children}
      </table>
    </div>
  );
}
