import React from 'react';
import { Missing } from '../core/Missing.jsx';

/**
 * The fact strip: a responsive grid of labelled fact tiles. A null/empty
 * value renders the "Информация отсутствует" marker instead of a fake value.
 */
export function FactList({ items = [], className = '', ...rest }) {
  return (
    <ul className={['facts', className].filter(Boolean).join(' ')} {...rest}>
      {items.map((it, i) => {
        const empty = it.value == null || it.value === '';
        return (
          <li key={i}>
            <span className="label">{it.label}</span>
            {empty ? <Missing /> : <span>{it.value}</span>}
          </li>
        );
      })}
    </ul>
  );
}
