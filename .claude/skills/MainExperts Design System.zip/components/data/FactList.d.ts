import type { ReactNode, HTMLAttributes } from 'react';

export interface FactItem {
  label: string;
  /** null or '' renders the data-gap marker. */
  value?: ReactNode;
}

export interface FactListProps extends HTMLAttributes<HTMLUListElement> {
  items: FactItem[];
  className?: string;
}

export declare function FactList(props: FactListProps): JSX.Element;
