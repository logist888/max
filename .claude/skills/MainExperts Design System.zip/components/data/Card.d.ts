import type { ReactNode, HTMLAttributes } from 'react';

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Card heading (renders in the display serif). */
  title?: ReactNode;
  /** If set, the title becomes a link. */
  href?: string;
  /** Small uppercase caramel label above the title. */
  eyebrow?: string;
  /** Inline-SVG icon; renders inside the rounded `.qic` plate (question cards). */
  icon?: ReactNode;
  /** Muted meta lines under the title (city, counts, price range…). */
  meta?: ReactNode[];
  className?: string;
  children?: ReactNode;
}

export declare function Card(props: CardProps): JSX.Element;
