One-line: the hover-lift card used both for entity tiles (university / city / direction) inside a `.card-list` grid and for "how to choose" question cards.

```jsx
<ul className="card-list grid-3">
  <li><Card title="МГУ им. М. В. Ломоносова" href="/vuz/mgu-3089/"
        meta={['Москва', '58 направлений', 'от 200 000 ₽ в год']} /></li>
</ul>

<Card icon={<CompassIcon/>} eyebrow="Шаг 1" title="С чего начать выбор">
  <p>...</p>
</Card>
```

Titles use the serif. Meta lines are muted. For grid layout wrap cards in `<ul className="card-list grid-2|grid-3|grid-4">` with `<li>` items.
