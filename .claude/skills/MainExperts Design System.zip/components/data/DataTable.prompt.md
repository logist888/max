One-line: the programmes / catalog data table — horizontally scrollable, numeric columns right-aligned with tabular figures, empty cells filled by the data-gap marker.

```jsx
<DataTable
  columns={[
    { key: 'dir', label: 'Направление' },
    { key: 'form', label: 'Форма' },
    { key: 'budget', label: 'Бюджет', num: true },
    { key: 'paid', label: 'Платно', num: true },
    { key: 'cost', label: 'Стоимость', num: true },
  ]}
  rows={[
    { dir: '09.03.01 Информатика', form: 'очная', budget: '120', paid: '80', cost: '242 000 ₽' },
    { dir: '38.03.01 Экономика', form: 'очная', budget: null, paid: '150', cost: '390 000 ₽', _start: true },
  ]}
/>
```

Positions without a price sort to the end (never shown as 0 ₽). `_start` draws the accent divider between direction groups.
