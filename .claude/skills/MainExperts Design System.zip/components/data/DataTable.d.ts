import type { ReactNode, TableHTMLAttributes } from 'react';

export interface Column {
  key: string;
  label: ReactNode;
  /** Right-align with tabular figures (counts, prices). */
  num?: boolean;
}

export interface DataTableProps extends TableHTMLAttributes<HTMLTableElement> {
  /** Column defs. Omit to render `children` (thead/tbody) manually. */
  columns?: Column[];
  /** Row objects keyed by column.key. A missing/empty cell shows the gap marker.
   *  Set `_start: true` to draw the accent top-border that separates directions. */
  rows?: Record<string, ReactNode>[];
  className?: string;
  children?: ReactNode;
}

export declare function DataTable(props: DataTableProps): JSX.Element;
