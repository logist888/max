One-line: a toggleable faceted-filter chip that carries its result count ("Москва (336)") and greys out when a choice would empty the list.

```jsx
<div className="filter-chips">
  <FilterChip pressed={f==='moskva'} count={336} onToggle={()=>setF('moskva')}>Москва</FilterChip>
  <FilterChip count={0} disabled>Нарьян-Мар</FilterChip>
</div>
```

Booking-level rule: values with a zero result in the current combination are disabled, not clickable — you can never reach an empty result set by clicking.
