import React from 'react';

/**
 * Breadcrumb trail: Главная → Регион → Город → Вуз. The last item is the
 * current page (non-link, bold). Separator is a right arrow.
 */
export function Breadcrumbs({ items = [], className = '', ...rest }) {
  return (
    <nav className={['breadcrumbs', className].filter(Boolean).join(' ')} aria-label="Хлебные крошки" {...rest}>
      {items.map((it, i) => {
        const last = i === items.length - 1;
        return (
          <React.Fragment key={i}>
            {i > 0 && ' → '}
            {last || !it.href ? (
              <span aria-current="page">{it.name}</span>
            ) : (
              <a href={it.href}>{it.name}</a>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
