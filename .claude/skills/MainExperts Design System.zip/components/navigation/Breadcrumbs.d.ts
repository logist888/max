import type { HTMLAttributes } from 'react';

export interface Crumb {
  name: string;
  /** Omit on the final (current) item. */
  href?: string;
}

export interface BreadcrumbsProps extends HTMLAttributes<HTMLElement> {
  /** Ordered trail, root first. The last entry renders as the current page. */
  items: Crumb[];
  className?: string;
}

export declare function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;
