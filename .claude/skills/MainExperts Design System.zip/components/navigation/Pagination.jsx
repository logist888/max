import React from 'react';

/**
 * Numbered pager. Current page is a filled gradient pill (non-link); other
 * pages are outlined links. Windows around the current page with ellipses.
 * Provide `hrefFor` for real links, or `onPage` for a click handler.
 */
export function Pagination({ page = 1, pageCount = 1, hrefFor, onPage, className = '', ...rest }) {
  if (pageCount <= 1) return null;
  const nums = [];
  const push = (n) => nums.push(n);
  const win = 1;
  for (let n = 1; n <= pageCount; n++) {
    if (n === 1 || n === pageCount || (n >= page - win && n <= page + win)) push(n);
    else if (nums[nums.length - 1] !== '…') push('…');
  }
  const item = (n) => {
    if (n === '…') return <span key={`e${Math.random()}`} aria-hidden="true">…</span>;
    if (n === page) return <span key={n} aria-current="page">{n}</span>;
    const onClick = onPage ? (e) => { e.preventDefault(); onPage(n); } : undefined;
    return <a key={n} href={hrefFor ? hrefFor(n) : '#'} onClick={onClick}>{n}</a>;
  };
  return (
    <nav className={['pagination', className].filter(Boolean).join(' ')} aria-label="Страницы" {...rest}>
      {nums.map(item)}
    </nav>
  );
}
