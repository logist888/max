import React from 'react';

/**
 * Underline tab switcher (view toggle on /vuzy/, /specialnosti/). Controlled:
 * pass `active` id and an `onChange` handler.
 */
export function Tabs({ tabs = [], active, onChange, className = '', ...rest }) {
  return (
    <div className={['tabs', className].filter(Boolean).join(' ')} role="tablist" {...rest}>
      {tabs.map((t) => {
        const on = t.id === active;
        return (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={on}
            className={['tab', on && 'is-active'].filter(Boolean).join(' ')}
            onClick={() => onChange && onChange(t.id)}
          >
            {t.label}
          </button>
        );
      })}
    </div>
  );
}
