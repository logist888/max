import React from 'react';

/**
 * Toggleable facet chip (aria-pressed). Pressed = filled caramel. Optionally
 * shows the facet result count in parentheses ("Москва (336)"). Disable when
 * the count would be zero — the platform never allows an empty result set.
 */
export function FilterChip({ pressed = false, count, disabled = false, onToggle, className = '', children, ...rest }) {
  return (
    <button
      type="button"
      className={['filter-chip', className].filter(Boolean).join(' ')}
      aria-pressed={pressed}
      disabled={disabled}
      onClick={() => !disabled && onToggle && onToggle(!pressed)}
      {...rest}
    >
      {children}
      {count != null && <> ({count.toLocaleString('ru-RU')})</>}
    </button>
  );
}
