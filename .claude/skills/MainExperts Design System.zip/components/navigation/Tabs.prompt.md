One-line: an underline tab switcher for flipping a catalog between views (e.g. «Вузы» / «По направлениям», «По алфавиту» / «По числу направлений»).

```jsx
const [view, setView] = React.useState('vuzy');
<Tabs active={view} onChange={setView} tabs={[
  { id: 'vuzy', label: 'Вузы' },
  { id: 'napravleniya', label: 'По направлениям' },
]} />
```

Controlled component. Active tab gets the caramel underline + bold. Sits on a bottom border shared with the content below.
