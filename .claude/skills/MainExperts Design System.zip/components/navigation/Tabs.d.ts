import type { HTMLAttributes } from 'react';

export interface TabItem {
  id: string;
  label: string;
}

export interface TabsProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> {
  tabs: TabItem[];
  /** id of the active tab. */
  active: string;
  /** Called with the clicked tab id. */
  onChange?: (id: string) => void;
  className?: string;
}

export declare function Tabs(props: TabsProps): JSX.Element;
