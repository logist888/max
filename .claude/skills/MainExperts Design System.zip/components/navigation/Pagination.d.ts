import type { HTMLAttributes } from 'react';

export interface PaginationProps extends HTMLAttributes<HTMLElement> {
  /** Current 1-based page. */
  page: number;
  /** Total number of pages. Renders nothing when <= 1. */
  pageCount: number;
  /** Build an href for a page number (SSR links). */
  hrefFor?: (page: number) => string;
  /** Click handler for a page number (SPA); preventDefault is applied. */
  onPage?: (page: number) => void;
  className?: string;
}

export declare function Pagination(props: PaginationProps): JSX.Element | null;
