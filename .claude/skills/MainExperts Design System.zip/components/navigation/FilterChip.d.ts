import type { ButtonHTMLAttributes } from 'react';
import type { ReactNode } from 'react';

export interface FilterChipProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> {
  /** Selected state — filled caramel when true. */
  pressed?: boolean;
  /** Facet result count, shown in parentheses. */
  count?: number;
  /** Grey out (use when the count in the current combination would be 0). */
  disabled?: boolean;
  /** Called with the next pressed value. */
  onToggle?: (next: boolean) => void;
  className?: string;
  children?: ReactNode;
}

export declare function FilterChip(props: FilterChipProps): JSX.Element;
