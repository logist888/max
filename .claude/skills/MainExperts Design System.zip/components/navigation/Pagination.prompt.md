One-line: a numbered pager for catalog lists — current page is a caramel gradient pill, others are outlined links, windowed with ellipses.

```jsx
<Pagination page={3} pageCount={24} hrefFor={(n) => `/vuzy/?p=${n}`} />
<Pagination page={p} pageCount={12} onPage={setP} />
```

Returns null for a single page. Note: paginated catalog pages beyond page 1 are `noindex` on the real platform.
