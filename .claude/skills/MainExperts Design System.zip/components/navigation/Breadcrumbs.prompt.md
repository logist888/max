One-line: the arrow-separated breadcrumb trail (Главная → Регион → Город → Вуз) shown at the top of every data page.

```jsx
<Breadcrumbs items={[
  { name: 'Главная', href: '/' },
  { name: 'Москва', href: '/gorod/moskva/' },
  { name: 'МГУ им. М. В. Ломоносова' },
]} />
```

Muted text; the final item is bold and non-clickable (current page). Order root → leaf.
