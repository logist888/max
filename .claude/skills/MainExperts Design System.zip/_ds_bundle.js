/* @ds-bundle: {"format":4,"namespace":"MainExpertsDesignSystem_96585d","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"Missing","sourcePath":"components/core/Missing.jsx"},{"name":"ZoneChip","sourcePath":"components/core/ZoneChip.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"FactList","sourcePath":"components/data/FactList.jsx"},{"name":"LevelGroup","sourcePath":"components/data/LevelGroup.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"FilterChip","sourcePath":"components/navigation/FilterChip.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"e46fcd00e33e","components/core/Button.jsx":"d1eaf062d613","components/core/Callout.jsx":"fa1e1a041ded","components/core/Missing.jsx":"2a38773f62d2","components/core/ZoneChip.jsx":"18e0c895be4a","components/data/Card.jsx":"55ff2e0413f9","components/data/DataTable.jsx":"461be29997a8","components/data/FactList.jsx":"4b83726def3a","components/data/LevelGroup.jsx":"86cae9cf6fc0","components/navigation/Breadcrumbs.jsx":"ec9959711330","components/navigation/FilterChip.jsx":"8245325eb9c1","components/navigation/Pagination.jsx":"5c47bf54d5ac","components/navigation/Tabs.jsx":"00f6e7df1ca0","ui_kits/vuz-navigator/CatalogScreen.jsx":"f452bf6f87f7","ui_kits/vuz-navigator/CompareScreen.jsx":"be26b686029d","ui_kits/vuz-navigator/Footer.jsx":"2b7309114067","ui_kits/vuz-navigator/Header.jsx":"ab153229af0d","ui_kits/vuz-navigator/HomeScreen.jsx":"4a53ba86abd5","ui_kits/vuz-navigator/QuizScreen.jsx":"eaaf29a46fba","ui_kits/vuz-navigator/VuzScreen.jsx":"7155da8122ba","ui_kits/vuz-navigator/app.jsx":"8ab57e52f66e","ui_kits/vuz-navigator/conversion.jsx":"969614b368bb","ui_kits/vuz-navigator/data.js":"4777f95e983d","ui_kits/vuz-navigator/icons.jsx":"86064ee133bd","ui_kits/vuz-navigator/monogram.jsx":"a14325cb1118"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MainExpertsDesignSystem_96585d = window.MainExpertsDesignSystem_96585d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Small rounded label for a boolean fact ("Есть бюджетные места",
 * "Общежитие"). Only ever states a TRUE flag — an absent flag is never
 * rendered as a negative badge (platform data rule).
 */
function Badge({
  tone = 'neutral',
  className = '',
  children,
  ...rest
}) {
  const cls = ['badge', tone === 'ok' && 'badge--ok', tone === 'info' && 'badge--info', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Primary action control. Caramel gradient pill (primary) or outlined surface
 * (secondary). Renders as <button> or <a>. On a dark hero, .hero context flips
 * primary to a light fill automatically via CSS.
 */
function Button({
  variant = 'primary',
  size,
  as = 'button',
  icon,
  disabled = false,
  className = '',
  children,
  ...rest
}) {
  const Tag = as;
  const cls = ['btn', `btn-${variant}`, size === 'sm' && 'btn-sm', className].filter(Boolean).join(' ');
  const extra = Tag === 'a' ? {
    'aria-disabled': disabled || undefined
  } : {
    disabled
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, extra, rest), icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Boxed callout. Two intents:
 *  - notice: neutral/caution note (amber left border) — e.g. a data caveat.
 *  - invite: conversion value-prop (accent left border) — the "next step"
 *    bridge to diagnostics. Accent, NOT a warning.
 */
function Callout({
  intent = 'notice',
  className = '',
  children,
  ...rest
}) {
  const cls = [intent === 'invite' ? 'invite' : 'notice', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/Missing.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The platform's signature "data gap" marker. A missing fact is shown
 * explicitly and italic — never hidden and never faked as a zero.
 */
function Missing({
  children = 'Информация отсутствует',
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['missing', className].filter(Boolean).join(' ')
  }, rest), children);
}
Object.assign(__ds_scope, { Missing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Missing.jsx", error: String((e && e.message) || e) }); }

// components/core/ZoneChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Semantic zone chip — the shared visual language with the MainExperts
 * screening product ("N зон риска из 6"). A colour-coded count/label:
 * risk (red), mid (amber/warn), ok (green).
 */
function ZoneChip({
  level = 'mid',
  count,
  label,
  className = '',
  children,
  ...rest
}) {
  const cls = ['zone-chip', `zone-chip--${level}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), count != null && /*#__PURE__*/React.createElement("strong", null, count), label ?? children);
}
Object.assign(__ds_scope, { ZoneChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ZoneChip.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Hover-lift content card. Used for entity tiles (a university, a city, a
 * direction) in a `.card-list` grid, and for "how to choose" question cards
 * (pass `icon` to get the rounded icon plate + `eyebrow`).
 */
function Card({
  title,
  href,
  eyebrow,
  icon,
  meta = [],
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['card', className].filter(Boolean).join(' ')
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "qic"
  }, icon), eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      margin: 0
    }
  }, eyebrow), title && /*#__PURE__*/React.createElement("h3", null, href ? /*#__PURE__*/React.createElement("a", {
    href: href
  }, title) : title), meta.map((m, i) => /*#__PURE__*/React.createElement("div", {
    className: "meta",
    key: i
  }, m)), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Horizontally-scrollable data table. Pass columns + rows for the common case
 * (numeric columns right-align with tabular figures; empty cells show the
 * data-gap marker), or pass children for full manual control.
 */
function DataTable({
  columns,
  rows = [],
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "table-wrap"
  }, /*#__PURE__*/React.createElement("table", _extends({
    className: className
  }, rest), columns && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: c.num ? {
      textAlign: 'right'
    } : undefined
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    className: r._start ? 'dir-start' : undefined
  }, columns.map(c => {
    const v = r[c.key];
    const empty = v == null || v === '';
    return /*#__PURE__*/React.createElement("td", {
      key: c.key,
      className: c.num ? 'num' : undefined
    }, empty ? /*#__PURE__*/React.createElement(__ds_scope.Missing, null) : v);
  }))))), children));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/FactList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The fact strip: a responsive grid of labelled fact tiles. A null/empty
 * value renders the "Информация отсутствует" marker instead of a fake value.
 */
function FactList({
  items = [],
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ul", _extends({
    className: ['facts', className].filter(Boolean).join(' ')
  }, rest), items.map((it, i) => {
    const empty = it.value == null || it.value === '';
    return /*#__PURE__*/React.createElement("li", {
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      className: "label"
    }, it.label), empty ? /*#__PURE__*/React.createElement(__ds_scope.Missing, null) : /*#__PURE__*/React.createElement("span", null, it.value));
  }));
}
Object.assign(__ds_scope, { FactList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/FactList.jsx", error: String((e && e.message) || e) }); }

// components/data/LevelGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Collapsible group of programmes by level (Бакалавриат, Магистратура, …).
 * The chevron and open/close animation come from the .level-group CSS.
 */
function LevelGroup({
  title,
  summary,
  defaultOpen = false,
  open,
  onToggle,
  className = '',
  children,
  ...rest
}) {
  const controlled = open != null;
  return /*#__PURE__*/React.createElement("details", _extends({
    className: ['level-group', className].filter(Boolean).join(' ')
  }, controlled ? {
    open
  } : {
    open: defaultOpen
  }, {
    onToggle: onToggle
  }, rest), /*#__PURE__*/React.createElement("summary", null, /*#__PURE__*/React.createElement("span", null, title), summary != null && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontWeight: 400
    }
  }, summary)), /*#__PURE__*/React.createElement("div", null, children));
}
Object.assign(__ds_scope, { LevelGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/LevelGroup.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Breadcrumb trail: Главная → Регион → Город → Вуз. The last item is the
 * current page (non-link, bold). Separator is a right arrow.
 */
function Breadcrumbs({
  items = [],
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: ['breadcrumbs', className].filter(Boolean).join(' '),
    "aria-label": "\u0425\u043B\u0435\u0431\u043D\u044B\u0435 \u043A\u0440\u043E\u0448\u043A\u0438"
  }, rest), items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, i > 0 && ' → ', last || !it.href ? /*#__PURE__*/React.createElement("span", {
      "aria-current": "page"
    }, it.name) : /*#__PURE__*/React.createElement("a", {
      href: it.href
    }, it.name));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/FilterChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Toggleable facet chip (aria-pressed). Pressed = filled caramel. Optionally
 * shows the facet result count in parentheses ("Москва (336)"). Disable when
 * the count would be zero — the platform never allows an empty result set.
 */
function FilterChip({
  pressed = false,
  count,
  disabled = false,
  onToggle,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: ['filter-chip', className].filter(Boolean).join(' '),
    "aria-pressed": pressed,
    disabled: disabled,
    onClick: () => !disabled && onToggle && onToggle(!pressed)
  }, rest), children, count != null && /*#__PURE__*/React.createElement(React.Fragment, null, " (", count.toLocaleString('ru-RU'), ")"));
}
Object.assign(__ds_scope, { FilterChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/FilterChip.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Numbered pager. Current page is a filled gradient pill (non-link); other
 * pages are outlined links. Windows around the current page with ellipses.
 * Provide `hrefFor` for real links, or `onPage` for a click handler.
 */
function Pagination({
  page = 1,
  pageCount = 1,
  hrefFor,
  onPage,
  className = '',
  ...rest
}) {
  if (pageCount <= 1) return null;
  const nums = [];
  const push = n => nums.push(n);
  const win = 1;
  for (let n = 1; n <= pageCount; n++) {
    if (n === 1 || n === pageCount || n >= page - win && n <= page + win) push(n);else if (nums[nums.length - 1] !== '…') push('…');
  }
  const item = n => {
    if (n === '…') return /*#__PURE__*/React.createElement("span", {
      key: `e${Math.random()}`,
      "aria-hidden": "true"
    }, "\u2026");
    if (n === page) return /*#__PURE__*/React.createElement("span", {
      key: n,
      "aria-current": "page"
    }, n);
    const onClick = onPage ? e => {
      e.preventDefault();
      onPage(n);
    } : undefined;
    return /*#__PURE__*/React.createElement("a", {
      key: n,
      href: hrefFor ? hrefFor(n) : '#',
      onClick: onClick
    }, n);
  };
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: ['pagination', className].filter(Boolean).join(' '),
    "aria-label": "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u044B"
  }, rest), nums.map(item));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Underline tab switcher (view toggle on /vuzy/, /specialnosti/). Controlled:
 * pass `active` id and an `onChange` handler.
 */
function Tabs({
  tabs = [],
  active,
  onChange,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['tabs', className].filter(Boolean).join(' '),
    role: "tablist"
  }, rest), tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      type: "button",
      role: "tab",
      "aria-selected": on,
      className: ['tab', on && 'is-active'].filter(Boolean).join(' '),
      onClick: () => onChange && onChange(t.id)
    }, t.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/CatalogScreen.jsx
try { (() => {
/* Catalog: faceted filters (city / level / budget / dormitory / military /
   cost), sort tabs, active-chip summary, university rows, pager. Filtering is
   real client-side over the sample set; zero-result values are disabled. */
function VNCatalog({
  onOpenVuz
}) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const {
    Button,
    Badge,
    FilterChip,
    Tabs,
    Pagination
  } = DS;
  const {
    vuzy
  } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = n => n.toLocaleString('ru-RU');
  const [cities, setCities] = React.useState(() => new Set());
  const [levels, setLevels] = React.useState(() => new Set());
  const [flags, setFlags] = React.useState({
    budget: false,
    dormitory: false,
    military: false
  });
  const [maxCost, setMaxCost] = React.useState(800000);
  const [sort, setSort] = React.useState('dirs');
  const [page, setPage] = React.useState(1);
  const cityList = React.useMemo(() => {
    const m = new Map();
    vuzy.forEach(v => m.set(v.city, (m.get(v.city) || 0) + 1));
    return [...m.entries()].map(([name, count]) => ({
      name,
      count
    })).sort((a, b) => b.count - a.count);
  }, []);
  const levelList = ['Бакалавриат', 'Магистратура', 'Специалитет'];
  const toggle = setter => key => setter(prev => {
    const next = new Set(prev);
    next.has(key) ? next.delete(key) : next.add(key);
    return next;
  });
  const toggleCity = toggle(setCities);
  const toggleLevel = toggle(setLevels);
  const matches = v => (cities.size === 0 || cities.has(v.city)) && (levels.size === 0 || v.levels.some(l => levels.has(l))) && (!flags.budget || v.budget) && (!flags.dormitory || v.dormitory) && (!flags.military || v.military) && v.costMin <= maxCost;
  const result = vuzy.filter(matches).sort((a, b) => {
    if (sort === 'alpha') return a.short.localeCompare(b.short, 'ru');
    if (sort === 'cost') return a.costMin - b.costMin;
    return b.directionsCount - a.directionsCount;
  });

  // facet count for a would-be city selection (respects other active filters)
  const cityFacet = name => vuzy.filter(v => v.city === name && (levels.size === 0 || v.levels.some(l => levels.has(l))) && (!flags.budget || v.budget) && (!flags.dormitory || v.dormitory) && (!flags.military || v.military) && v.costMin <= maxCost).length;
  const activeChips = [];
  cities.forEach(c => activeChips.push({
    k: 'city:' + c,
    label: c,
    clear: () => toggleCity(c)
  }));
  levels.forEach(l => activeChips.push({
    k: 'lvl:' + l,
    label: l,
    clear: () => toggleLevel(l)
  }));
  if (flags.budget) activeChips.push({
    k: 'budget',
    label: 'Есть бюджет',
    clear: () => setFlags(f => ({
      ...f,
      budget: false
    }))
  });
  if (flags.dormitory) activeChips.push({
    k: 'dorm',
    label: 'Общежитие',
    clear: () => setFlags(f => ({
      ...f,
      dormitory: false
    }))
  });
  if (flags.military) activeChips.push({
    k: 'mil',
    label: 'Военная кафедра',
    clear: () => setFlags(f => ({
      ...f,
      military: false
    }))
  });
  if (maxCost < 800000) activeChips.push({
    k: 'cost',
    label: `до ${fmt(maxCost)} ₽`,
    clear: () => setMaxCost(800000)
  });
  const clearAll = () => {
    setCities(new Set());
    setLevels(new Set());
    setFlags({
      budget: false,
      dormitory: false,
      military: false
    });
    setMaxCost(800000);
  };
  const row = v => /*#__PURE__*/React.createElement("li", {
    key: v.id,
    className: "card",
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      minWidth: 0,
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement(window.VNMono, {
    name: v.short,
    size: 46
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpenVuz(v);
    }
  }, v.short)), /*#__PURE__*/React.createElement("div", {
    className: "meta",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(I.MapPin, {
    size: 14
  }), " ", v.city), /*#__PURE__*/React.createElement("div", {
    className: "badges",
    style: {
      margin: '10px 0 0'
    }
  }, v.budget && /*#__PURE__*/React.createElement(Badge, {
    tone: "ok"
  }, "\u0415\u0441\u0442\u044C \u0431\u044E\u0434\u0436\u0435\u0442"), v.dormitory && /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "\u041E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435"), v.military && /*#__PURE__*/React.createElement(Badge, {
    tone: "info"
  }, "\u0412\u043E\u0435\u043D\u043D\u0430\u044F \u043A\u0430\u0444\u0435\u0434\u0440\u0430")), /*#__PURE__*/React.createElement("div", {
    className: "meta",
    style: {
      marginTop: 8
    }
  }, v.levels.join(' · ')))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      flex: '0 0 auto',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.5rem',
      fontWeight: 700,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--accent-strong)'
    }
  }, v.directionsCount), /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, "\u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439"), /*#__PURE__*/React.createElement("div", {
    className: "meta",
    style: {
      fontVariantNumeric: 'tabular-nums'
    }
  }, "\u043E\u0442 ", fmt(v.costMin), " \u20BD/\u0433\u043E\u0434"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    style: {
      marginTop: 6
    },
    onClick: () => onOpenVuz(v)
  }, "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443")));
  const group = (title, children) => /*#__PURE__*/React.createElement("div", {
    className: "filter-group"
  }, /*#__PURE__*/React.createElement("div", {
    className: "filter-group-title"
  }, title), children);
  return /*#__PURE__*/React.createElement("main", {
    className: "container"
  }, /*#__PURE__*/React.createElement("nav", {
    className: "breadcrumbs"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u0413\u043B\u0430\u0432\u043D\u0430\u044F"), " \u2192 ", /*#__PURE__*/React.createElement("span", {
    "aria-current": "page"
  }, "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0432\u0443\u0437\u043E\u0432")), /*#__PURE__*/React.createElement("h1", null, "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u0432\u0443\u0437\u043E\u0432"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      marginTop: 0,
      maxWidth: '60ch'
    }
  }, fmt(window.VN_DATA.stats.vuzy), " \u0432\u0443\u0437\u043E\u0432 \u043F\u043E \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0439 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435. \u041E\u0442\u0444\u0438\u043B\u044C\u0442\u0440\u0443\u0439\u0442\u0435 \u043F\u043E \u0433\u043E\u0440\u043E\u0434\u0443, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044E \u0438 \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u0438 \u2014 \u043F\u0443\u0441\u0442\u043E\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F."), /*#__PURE__*/React.createElement(Tabs, {
    active: sort,
    onChange: setSort,
    tabs: [{
      id: 'dirs',
      label: 'По числу направлений'
    }, {
      id: 'alpha',
      label: 'По алфавиту'
    }, {
      id: 'cost',
      label: 'По стоимости'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    className: "filters"
  }, /*#__PURE__*/React.createElement("div", {
    className: "filters-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "filters-count"
  }, result.length, " ", result.length === 1 ? 'вуз' : 'вузов', " \u043F\u043E \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C"), activeChips.length > 0 && /*#__PURE__*/React.createElement("button", {
    className: "filters-clear-top",
    onClick: clearAll
  }, "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0432\u0441\u0451")), /*#__PURE__*/React.createElement("div", {
    className: "filters-active"
  }, activeChips.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.k,
    className: "active-chip",
    onClick: c.clear
  }, c.label, " ", /*#__PURE__*/React.createElement("span", null, "\u2715")))), /*#__PURE__*/React.createElement("div", {
    className: "filters-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "filters-groups"
  }, group('Город', /*#__PURE__*/React.createElement("div", {
    className: "filter-chips"
  }, cityList.map(c => {
    const n = cityFacet(c.name);
    return /*#__PURE__*/React.createElement(FilterChip, {
      key: c.name,
      pressed: cities.has(c.name),
      count: n,
      disabled: n === 0 && !cities.has(c.name),
      onToggle: () => toggleCity(c.name)
    }, c.name);
  }))), group('Уровень', /*#__PURE__*/React.createElement("div", {
    className: "filter-chips"
  }, levelList.map(l => /*#__PURE__*/React.createElement(FilterChip, {
    key: l,
    pressed: levels.has(l),
    onToggle: () => toggleLevel(l)
  }, l)))), group('Условия', /*#__PURE__*/React.createElement("div", {
    className: "filter-chips"
  }, /*#__PURE__*/React.createElement(FilterChip, {
    pressed: flags.budget,
    onToggle: () => setFlags(f => ({
      ...f,
      budget: !f.budget
    }))
  }, "\u0415\u0441\u0442\u044C \u0431\u044E\u0434\u0436\u0435\u0442"), /*#__PURE__*/React.createElement(FilterChip, {
    pressed: flags.dormitory,
    onToggle: () => setFlags(f => ({
      ...f,
      dormitory: !f.dormitory
    }))
  }, "\u041E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435"), /*#__PURE__*/React.createElement(FilterChip, {
    pressed: flags.military,
    onToggle: () => setFlags(f => ({
      ...f,
      military: !f.military
    }))
  }, "\u0412\u043E\u0435\u043D\u043D\u0430\u044F \u043A\u0430\u0444\u0435\u0434\u0440\u0430"))), group('Стоимость (платно), до', /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.VNConv.CostHistogram, {
    maxCost: maxCost
  }), /*#__PURE__*/React.createElement("div", {
    className: "filter-range"
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 138000,
    max: 800000,
    step: 1000,
    value: maxCost,
    onChange: e => setMaxCost(+e.target.value),
    style: {
      width: '100%',
      accentColor: 'var(--accent)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "filter-range-unit",
    style: {
      fontVariantNumeric: 'tabular-nums'
    }
  }, maxCost >= 800000 ? 'без ограничения' : `до ${fmt(maxCost)} ₽`))))))), result.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "filters-empty"
  }, "\u041F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0448\u043B\u043E\u0441\u044C \u2014 \u0441\u043D\u0438\u043C\u0438\u0442\u0435 \u043E\u0434\u043D\u043E \u0438\u0437 \u0443\u0441\u043B\u043E\u0432\u0438\u0439.") : /*#__PURE__*/React.createElement("ul", {
    className: "card-list",
    style: {
      marginTop: 'var(--space-6)'
    }
  }, result.map(row)), /*#__PURE__*/React.createElement(Pagination, {
    page: page,
    pageCount: 24,
    onPage: setPage
  }), /*#__PURE__*/React.createElement("p", {
    className: "missing",
    style: {
      fontSize: '.8125rem'
    }
  }, "\u041F\u043E\u043A\u0430\u0437\u0430\u043D\u044B \u043F\u0440\u0438\u043C\u0435\u0440\u044B \u0438\u0437 \u0434\u0435\u043C\u043E-\u043D\u0430\u0431\u043E\u0440\u0430; \u0441\u043E 2-\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u2014 noindex."));
}
window.VNCatalog = VNCatalog;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/CatalogScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/CompareScreen.jsx
try { (() => {
/* Comparison — up to 4 universities side by side, facts only, empty cells as
   the data-gap marker. Stored in the browser; the real page is noindex. */
function VNCompare({
  onOpenVuz
}) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const {
    Button,
    Missing,
    Badge
  } = DS;
  const {
    vuzy
  } = window.VN_DATA;
  const fmt = n => n.toLocaleString('ru-RU');
  const [ids, setIds] = React.useState(() => vuzy.slice(0, 3).map(v => v.id));
  const chosen = ids.map(id => vuzy.find(v => v.id === id)).filter(Boolean);
  const remove = id => setIds(a => a.filter(x => x !== id));
  const addable = vuzy.filter(v => !ids.includes(v.id));
  const add = () => {
    if (ids.length < 4 && addable[0]) setIds(a => [...a, addable[0].id]);
  };
  const yn = b => b ? 'да' : /*#__PURE__*/React.createElement(Missing, null);
  const rows = [['Город', v => v.city], ['Уровни', v => v.levels.join(', ')], ['Направлений', v => fmt(v.directionsCount)], ['Бюджетные места', v => v.budget ? 'есть' : /*#__PURE__*/React.createElement(Missing, null)], ['Стоимость (платно)', v => v.costMin === v.costMax ? `${fmt(v.costMin)} ₽` : `${fmt(v.costMin)}–${fmt(v.costMax)} ₽`], ['Общежитие', v => v.dormitory ? v.dormPlaces ? `${fmt(v.dormPlaces)} мест` : 'есть' : /*#__PURE__*/React.createElement(Missing, null)], ['Военная кафедра', v => yn(v.military)]];
  return /*#__PURE__*/React.createElement("main", {
    className: "container"
  }, /*#__PURE__*/React.createElement("nav", {
    className: "breadcrumbs"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault()
  }, "\u0413\u043B\u0430\u0432\u043D\u0430\u044F"), " \u2192 ", /*#__PURE__*/React.createElement("span", {
    "aria-current": "page"
  }, "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435")), /*#__PURE__*/React.createElement("h1", null, "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u0432\u0443\u0437\u043E\u0432"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      marginTop: 0
    }
  }, "\u0414\u043E \u0447\u0435\u0442\u044B\u0440\u0451\u0445 \u0432\u0443\u0437\u043E\u0432 \u0440\u044F\u0434\u043E\u043C \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0444\u0430\u043A\u0442\u044B \u0431\u0430\u0437\u044B. \u041F\u0443\u0441\u0442\u0430\u044F \u044F\u0447\u0435\u0439\u043A\u0430 \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442, \u0447\u0442\u043E \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0435\u0442."), /*#__PURE__*/React.createElement("div", {
    className: "table-wrap",
    style: {
      marginTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      minWidth: 150
    }
  }), chosen.map(v => /*#__PURE__*/React.createElement("th", {
    key: v.id,
    style: {
      minWidth: 170
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(window.VNMono, {
    name: v.short,
    size: 38,
    radius: 10
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => remove(v.id),
    "aria-label": "\u0423\u0431\u0440\u0430\u0442\u044C",
    style: {
      background: 'none',
      border: 0,
      cursor: 'pointer',
      color: 'var(--text-muted)',
      fontSize: '1rem',
      lineHeight: 1
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpenVuz(v);
    },
    style: {
      display: 'block',
      marginTop: 8,
      textTransform: 'none',
      letterSpacing: 0,
      fontSize: '.95rem',
      fontWeight: 600,
      color: 'var(--text)'
    }
  }, v.short))), ids.length < 4 && /*#__PURE__*/React.createElement("th", {
    style: {
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    disabled: !addable.length,
    onClick: add
  }, "+ \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0432\u0443\u0437")))), /*#__PURE__*/React.createElement("tbody", null, rows.map(([label, get]) => /*#__PURE__*/React.createElement("tr", {
    key: label
  }, /*#__PURE__*/React.createElement("th", {
    scope: "row",
    style: {
      color: 'var(--text-muted)'
    }
  }, label), chosen.map(v => /*#__PURE__*/React.createElement("td", {
    key: v.id
  }, get(v))), ids.length < 4 && /*#__PURE__*/React.createElement("td", null)))))), /*#__PURE__*/React.createElement("p", {
    className: "missing",
    style: {
      fontSize: '.8125rem',
      marginTop: 'var(--space-4)'
    }
  }, "\u0421\u043E\u0441\u0442\u0430\u0432 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044F \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435 \u0438 \u0432 \u0441\u0441\u044B\u043B\u043A\u0435; \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u2014 noindex."));
}
window.VNCompare = VNCompare;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/CompareScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/Footer.jsx
try { (() => {
/* Site footer: section columns + the source/date provenance line every
   data page carries (YMYL trust practice). */
function VNFooter() {
  const {
    meta
  } = window.VN_DATA;
  const col = (title, items) => /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      color: 'var(--text)',
      marginBottom: 8
    }
  }, title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gap: 6
    }
  }, items.map(t => /*#__PURE__*/React.createElement("li", {
    key: t
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault()
  }, t)))));
  return /*#__PURE__*/React.createElement("footer", {
    className: "site-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-8)',
      gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
      marginBottom: 'var(--space-6)'
    }
  }, col('Разделы', ['Каталог вузов', 'Регионы и города', 'Направления', 'Сравнение вузов']), col('О проекте', ['О данных', 'Как выбирать вуз', 'Пройти тест', 'Частые вопросы']), col('Данные', ['Источник и актуальность', 'Что означает «пробел»', 'Правила приёма'])), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)',
      paddingTop: 'var(--space-4)',
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u0434\u0430\u043D\u043D\u044B\u0445: ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text)'
    }
  }, meta.source), " \xB7 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0430 \u043E\u0442 ", meta.snapshot, " \xB7 \u043F\u0440\u0438\u0451\u043C ", meta.campaign), /*#__PURE__*/React.createElement("span", null, "\xA9 2026 MainExperts. \u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435; \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0439\u0442\u0435 \u043D\u0430 \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0445 \u0441\u0430\u0439\u0442\u0430\u0445 \u0432\u0443\u0437\u043E\u0432."))));
}
window.VNFooter = VNFooter;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/Header.jsx
try { (() => {
/* Site header: brand lockup, search field, primary nav, quiz CTA, burger. */
function VNHeader({
  onNav,
  current
}) {
  const {
    Search
  } = window.VNIcons;
  const [open, setOpen] = React.useState(false);
  const go = id => e => {
    e.preventDefault();
    onNav(id);
    setOpen(false);
  };
  const links = [['home', 'Главная', true], ['catalog', 'Каталог вузов'], ['regions', 'Регионы'], ['directions', 'Направления'], ['compare', 'Сравнение'], ['test', 'Тест']];
  return /*#__PURE__*/React.createElement("header", {
    className: 'site-header' + (open ? ' nav-open' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "header-top"
  }, /*#__PURE__*/React.createElement("a", {
    className: "brand",
    href: "#",
    onClick: go('home')
  }, /*#__PURE__*/React.createElement("img", {
    className: "brand-mark",
    src: "../../assets/logo.png",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", null, "MainExperts", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontWeight: 500
    }
  }, " \xB7 \u0412\u0423\u0417-\u043D\u0430\u0432\u0438\u0433\u0430\u0442\u043E\u0440"))), /*#__PURE__*/React.createElement("div", {
    className: "header-actions"
  }, /*#__PURE__*/React.createElement("a", {
    className: "nav-cta",
    href: "#",
    onClick: go('test')
  }, "\u041F\u0440\u043E\u0439\u0442\u0438 \u0442\u0435\u0441\u0442"), /*#__PURE__*/React.createElement("button", {
    className: "nav-toggle",
    "aria-label": "\u041C\u0435\u043D\u044E",
    "aria-expanded": open,
    onClick: () => setOpen(o => !o)
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-toggle-bars"
  })))), /*#__PURE__*/React.createElement("div", {
    id: "site-search",
    style: {
      flex: '1 1 300px',
      maxWidth: 430
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '9px 14px',
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-s)',
      color: 'var(--text-muted)',
      boxShadow: 'var(--shadow-1)'
    }
  }, /*#__PURE__*/React.createElement(Search, {
    size: 17
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "\u041F\u043E\u0438\u0441\u043A \u0432\u0443\u0437\u0430, \u0433\u043E\u0440\u043E\u0434\u0430, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u2026",
    onFocus: go('catalog'),
    readOnly: true,
    style: {
      border: 0,
      outline: 'none',
      background: 'transparent',
      font: 'inherit',
      color: 'var(--text)',
      width: '100%',
      cursor: 'pointer'
    }
  }))), /*#__PURE__*/React.createElement("nav", {
    className: "site-nav"
  }, links.map(([id, label, home]) => /*#__PURE__*/React.createElement("a", {
    key: id,
    href: "#",
    className: home ? 'nav-home' : undefined,
    "aria-current": current === id ? 'page' : undefined,
    style: current === id ? {
      color: 'var(--text)',
      fontWeight: 600
    } : undefined,
    onClick: go(id)
  }, label)))));
}
window.VNHeader = VNHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/HomeScreen.jsx
try { (() => {
/* Home: hero with live stats + "Карта выбора" preview, how-to-choose cards,
   popular universities, cities, direction groups, and the quiz bridge. */
function VNHome({
  onNav,
  onOpenVuz
}) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const {
    Button,
    ZoneChip,
    Card,
    Callout
  } = DS;
  const {
    stats,
    cities,
    ugs,
    vuzy,
    meta
  } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = n => n.toLocaleString('ru-RU');
  const stop = fn => e => {
    e.preventDefault();
    fn && fn();
  };
  return /*#__PURE__*/React.createElement("main", {
    className: "container"
  }, /*#__PURE__*/React.createElement("section", {
    className: "hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-copy"
  }, /*#__PURE__*/React.createElement("h1", null, "\u0412\u044B\u0431\u043E\u0440 \u0432\u0443\u0437\u0430 \u0431\u0435\u0437 \u0434\u043E\u0433\u0430\u0434\u043E\u043A"), /*#__PURE__*/React.createElement("p", null, "\u0412\u0441\u0435 \u0432\u0443\u0437\u044B \u0420\u043E\u0441\u0441\u0438\u0438, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0438 \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F \u2014 \u043F\u043E \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0439 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0444\u0430\u043A\u0442\u044B \u0446\u0435\u043B\u0438\u043A\u043E\u043C, \u0430 \u043F\u043E\u0442\u043E\u043C \u043F\u043E\u043C\u043E\u0436\u0435\u043C \u043F\u043E\u043D\u044F\u0442\u044C, \u0447\u0442\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0438\u043C\u0435\u043D\u043D\u043E \u0432\u0430\u043C."), /*#__PURE__*/React.createElement("div", {
    className: "actions"
  }, /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#",
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(I.Landmark, {
      size: 18
    }),
    onClick: stop(() => onNav('catalog'))
  }, "\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C ", fmt(stats.vuzy), " \u0432\u0443\u0437\u043E\u0432"), /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#",
    variant: "secondary",
    icon: /*#__PURE__*/React.createElement(I.Compass, {
      size: 18
    }),
    onClick: stop(() => onNav('test'))
  }, "\u041F\u0440\u043E\u0439\u0442\u0438 \u0442\u0435\u0441\u0442")), /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "chip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, fmt(stats.goroda)), " \u0433\u043E\u0440\u043E\u0434\u043E\u0432"), /*#__PURE__*/React.createElement("span", {
    className: "chip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, fmt(stats.napravleniya)), " \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439"), /*#__PURE__*/React.createElement("span", {
    className: "chip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "num"
  }, fmt(stats.stranicy)), " \u0441\u0442\u0440\u0430\u043D\u0438\u0446 \u0434\u0430\u043D\u043D\u044B\u0445")), /*#__PURE__*/React.createElement("div", {
    className: "prov"
  }, "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u0434\u0430\u043D\u043D\u044B\u0445: ", /*#__PURE__*/React.createElement("span", {
    className: "src"
  }, meta.source), " \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0430 \u043E\u0442 ", meta.snapshot, " \xB7 \u043F\u0440\u0438\u0451\u043C ", meta.campaign), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(window.VNConv.TrustBadge, {
    style: {
      background: 'rgba(255,255,255,.16)',
      color: '#fff'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "reveal in",
    style: {
      background: 'var(--surface)',
      color: 'var(--text)',
      borderRadius: 18,
      padding: 20,
      boxShadow: 'var(--shadow-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      margin: 0
    }
  }, "\u041A\u0430\u0440\u0442\u0430 \u0432\u044B\u0431\u043E\u0440\u0430"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      margin: '6px 0 10px'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.15rem'
    }
  }, "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D \u043D\u0430 40%"), /*#__PURE__*/React.createElement(ZoneChip, {
    level: "mid",
    count: 3,
    label: "\u0438\u0437 6 \u0437\u043E\u043D"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      borderRadius: 999,
      background: 'var(--surface-2)',
      overflow: 'hidden',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '40%',
      height: '100%',
      background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))'
    }
  })), [['Интересы и склонности', 'ok', 'сильная сторона'], ['Рынок профессий', 'risk', 'зона риска'], ['Понимание себя', 'mid', 'средняя зона']].map(([k, lvl, lab]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '8px 0',
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.92rem'
    }
  }, k), /*#__PURE__*/React.createElement(ZoneChip, {
    level: lvl,
    label: lab
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    style: {
      width: '100%',
      marginTop: 14
    },
    onClick: () => onNav('test')
  }, "\u0421\u043E\u0431\u0440\u0430\u0442\u044C \u043C\u043E\u044E \u043A\u0430\u0440\u0442\u0443 \u2192")))), /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, "\u041A\u0430\u043A \u044D\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442"), /*#__PURE__*/React.createElement("h2", {
    className: "tight",
    style: {
      marginTop: 'var(--space-2)'
    }
  }, "\u0422\u0440\u0438 \u0448\u0430\u0433\u0430 \u043A \u0440\u0435\u0448\u0435\u043D\u0438\u044E"), /*#__PURE__*/React.createElement("ul", {
    className: "card-list grid-3"
  }, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Card, {
    icon: /*#__PURE__*/React.createElement(I.Landmark, null),
    eyebrow: "\u0428\u0430\u0433 1",
    title: "\u041D\u0430\u0439\u0434\u0438\u0442\u0435 \u0432\u0443\u0437\u044B \u043F\u043E \u0444\u0430\u043A\u0442\u0430\u043C"
  }, "\u0424\u0438\u043B\u044C\u0442\u0440\u0443\u0439\u0442\u0435 \u043F\u043E \u0433\u043E\u0440\u043E\u0434\u0443, \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044E, \u0431\u044E\u0434\u0436\u0435\u0442\u0443 \u0438 \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u0438. \u041F\u0443\u0441\u0442\u043E\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043D\u0435\u043B\u044C\u0437\u044F.")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Card, {
    icon: /*#__PURE__*/React.createElement(I.Compare, null),
    eyebrow: "\u0428\u0430\u0433 2",
    title: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B"
  }, "\u0414\u043E \u0447\u0435\u0442\u044B\u0440\u0451\u0445 \u0432\u0443\u0437\u043E\u0432 \u0440\u044F\u0434\u043E\u043C: \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F, \u043C\u0435\u0441\u0442\u0430, \u0432\u0438\u043B\u043A\u0430 \u0446\u0435\u043D, \u043E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0444\u0430\u043A\u0442\u044B \u0431\u0430\u0437\u044B.")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Card, {
    icon: /*#__PURE__*/React.createElement(I.Compass, null),
    eyebrow: "\u0428\u0430\u0433 3",
    title: "\u041F\u043E\u0439\u043C\u0438\u0442\u0435, \u0447\u0442\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442"
  }, "\u0424\u0430\u043A\u0442\u044B \u043D\u0435 \u0433\u043E\u0432\u043E\u0440\u044F\u0442, \u0447\u0442\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0438\u043C\u0435\u043D\u043D\u043E \u0432\u0430\u043C. \u041A\u043E\u0440\u043E\u0442\u043A\u0438\u0439 \u0442\u0435\u0441\u0442 \u043D\u0430\u043C\u0435\u0442\u0438\u0442 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0448\u0430\u0433."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h2", null, "\u041F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0435 \u0432\u0443\u0437\u044B"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: stop(() => onNav('catalog'))
  }, "\u0412\u0435\u0441\u044C \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u2192")), /*#__PURE__*/React.createElement("ul", {
    className: "card-list grid-3"
  }, vuzy.slice(0, 6).map(v => /*#__PURE__*/React.createElement("li", {
    key: v.id
  }, /*#__PURE__*/React.createElement(Card, {
    title: v.short,
    href: "#",
    icon: /*#__PURE__*/React.createElement(window.VNMono, {
      name: v.short,
      size: 40,
      radius: 11
    }),
    meta: [v.city, `${v.directionsCount} направлений`, `от ${fmt(v.costMin)} ₽ в год`],
    onClick: stop(() => onOpenVuz(v)),
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "badges",
    style: {
      margin: '10px 0 0'
    }
  }, v.budget && /*#__PURE__*/React.createElement(DS.Badge, {
    tone: "ok"
  }, "\u0411\u044E\u0434\u0436\u0435\u0442"), v.dormitory && /*#__PURE__*/React.createElement(DS.Badge, {
    tone: "neutral"
  }, "\u041E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435")))))), /*#__PURE__*/React.createElement("h2", null, "\u0413\u043E\u0440\u043E\u0434\u0430"), /*#__PURE__*/React.createElement("ul", {
    className: "card-list grid-4"
  }, cities.slice(0, 8).map(c => /*#__PURE__*/React.createElement("li", {
    key: c.slug
  }, /*#__PURE__*/React.createElement(Card, {
    title: c.name,
    href: "#",
    meta: [`${c.count} вузов`],
    onClick: stop(() => onNav('catalog')),
    style: {
      cursor: 'pointer'
    }
  })))), /*#__PURE__*/React.createElement("h2", null, "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0433\u0440\u0443\u043F\u043F\u0430\u043C"), /*#__PURE__*/React.createElement("ul", {
    className: "card-list grid-3"
  }, ugs.map(g => /*#__PURE__*/React.createElement("li", {
    key: g.code
  }, /*#__PURE__*/React.createElement(Card, {
    title: `${g.code} · ${g.name}`,
    href: "#",
    meta: [`${g.dirs} направлений`, `${fmt(g.vuzy)} вузов`],
    onClick: stop(() => onNav('directions')),
    style: {
      cursor: 'pointer'
    }
  })))), /*#__PURE__*/React.createElement(Callout, {
    intent: "invite",
    style: {
      marginTop: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      flexWrap: 'wrap',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '46ch'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.2rem',
      display: 'block',
      marginBottom: 4
    }
  }, "\u0417\u043D\u0430\u0435\u0442\u0435 7\u201310 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0439, \u0430 \u0438\u0445 \u0431\u043E\u043B\u044C\u0448\u0435 250 000"), "\u0424\u0430\u043A\u0442\u044B \u043D\u0435 \u0433\u043E\u0432\u043E\u0440\u044F\u0442, \u0447\u0442\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0438\u043C\u0435\u043D\u043D\u043E \u0432\u0430\u043C. \u0422\u0435\u0441\u0442 \u043D\u0430 5\u20137 \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432 \u043D\u0430\u043C\u0435\u0442\u0438\u0442 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0448\u0430\u0433 \u2014 \u0431\u0435\u0437 \u043B\u0438\u0447\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => onNav('test')
  }, "\u041F\u0440\u043E\u0439\u0442\u0438 \u0442\u0435\u0441\u0442"))));
}
window.VNHome = VNHome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/QuizScreen.jsx
try { (() => {
/* Quiz /test/ — the conversion bridge. 5 questions, no personal data. Two
   outcomes: "know where you're going" → route through the catalog;
   "still exploring" → risk zones + a bridge to the diagnostics goal (UTM). */
function VNQuiz({
  onNav
}) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const {
    Button,
    FilterChip,
    ZoneChip,
    Callout,
    Card
  } = DS;
  const I = window.VNIcons;
  const QUESTIONS = [{
    id: 'who',
    q: 'Кто проходит тест?',
    multi: false,
    opts: ['9 класс', '10 класс', '11 класс', 'Выпускник / СПО', 'Родитель']
  }, {
    id: 'sure',
    q: 'Насколько определились с выбором?',
    multi: false,
    opts: ['Уверен(а) в направлении', 'Есть 2–3 варианта', 'Совсем не определился(ась)']
  }, {
    id: 'decided',
    q: 'Что уже решено?',
    multi: true,
    opts: ['Город', 'Направление', 'Конкретный вуз', 'Пока ничего']
  }, {
    id: 'ugs',
    q: 'Какие области ближе?',
    multi: true,
    opts: ['ИТ и математика', 'Экономика и управление', 'Инженерия', 'Гуманитарные науки', 'Медицина', 'Ещё не знаю']
  }, {
    id: 'stop',
    q: 'Что мешает решиться?',
    multi: false,
    opts: ['Не знаю своих сильных сторон', 'Боюсь ошибиться с профессией', 'Не понимаю рынок труда', 'Ничего, всё ясно']
  }];
  const [step, setStep] = React.useState(0);
  const [ans, setAns] = React.useState({});
  const done = step >= QUESTIONS.length;
  const pick = (q, opt) => setAns(a => {
    if (!q.multi) return {
      ...a,
      [q.id]: opt
    };
    const cur = new Set(a[q.id] || []);
    cur.has(opt) ? cur.delete(opt) : cur.add(opt);
    return {
      ...a,
      [q.id]: [...cur]
    };
  });
  const isPicked = (q, opt) => q.multi ? (ans[q.id] || []).includes(opt) : ans[q.id] === opt;
  const answered = q => q.multi ? (ans[q.id] || []).length > 0 : !!ans[q.id];
  const pct = Math.round(Math.min(step, QUESTIONS.length) / QUESTIONS.length * 100);
  if (!done) {
    const q = QUESTIONS[step];
    return /*#__PURE__*/React.createElement("main", {
      className: "container",
      style: {
        maxWidth: 720
      }
    }, /*#__PURE__*/React.createElement("nav", {
      className: "breadcrumbs"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNav('home');
      }
    }, "\u0413\u043B\u0430\u0432\u043D\u0430\u044F"), " \u2192 ", /*#__PURE__*/React.createElement("span", {
      "aria-current": "page"
    }, "\u0422\u0435\u0441\u0442")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 'var(--space-6)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "eyebrow",
      style: {
        margin: 0
      }
    }, "\u0412\u043E\u043F\u0440\u043E\u0441 ", step + 1, " \u0438\u0437 ", QUESTIONS.length), /*#__PURE__*/React.createElement("span", {
      className: "filters-count",
      style: {
        fontVariantNumeric: 'tabular-nums'
      }
    }, pct, "%")), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 8,
        borderRadius: 999,
        background: 'var(--surface-2)',
        overflow: 'hidden',
        margin: '8px 0 var(--space-6)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: pct + '%',
        height: '100%',
        background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))',
        transition: 'width .25s ease'
      }
    })), /*#__PURE__*/React.createElement("h1", {
      style: {
        marginTop: 0
      }
    }, q.q), q.multi && /*#__PURE__*/React.createElement("p", {
      className: "missing",
      style: {
        marginTop: -8
      }
    }, "\u043C\u043E\u0436\u043D\u043E \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E"), /*#__PURE__*/React.createElement("div", {
      className: "filter-chips",
      style: {
        gap: 10,
        marginTop: 'var(--space-4)'
      }
    }, q.opts.map(o => /*#__PURE__*/React.createElement(FilterChip, {
      key: o,
      pressed: isPicked(q, o),
      onToggle: () => pick(q, o),
      style: {
        fontSize: '1rem',
        padding: '10px 16px'
      }
    }, o))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        marginTop: 'var(--space-8)'
      }
    }, step > 0 && /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => setStep(s => s - 1)
    }, "\u041D\u0430\u0437\u0430\u0434"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      disabled: !answered(q),
      onClick: () => setStep(s => s + 1),
      style: {
        marginLeft: 'auto'
      }
    }, step === QUESTIONS.length - 1 ? 'Показать результат' : 'Дальше')), /*#__PURE__*/React.createElement("p", {
      className: "missing",
      style: {
        fontSize: '.8125rem',
        marginTop: 'var(--space-6)'
      }
    }, "\u0422\u0435\u0441\u0442 \u043D\u0435 \u0441\u043E\u0431\u0438\u0440\u0430\u0435\u0442 \u043B\u0438\u0447\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0432\u0430\u0448\u0435\u043C \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435."));
  }

  // ---- result
  const knows = ans.sure === 'Уверен(а) в направлении';
  const restart = () => {
    setAns({});
    setStep(0);
  };
  const zone = (label, lvl, note) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 0',
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, note)), /*#__PURE__*/React.createElement(ZoneChip, {
    level: lvl,
    label: lvl === 'ok' ? 'опора' : lvl === 'mid' ? 'средняя' : 'зона роста'
  }));
  const knowsInterests = (ans.ugs || []).length > 0 && !(ans.ugs || []).includes('Ещё не знаю');
  const selfLevel = ans.stop === 'Не знаю своих сильных сторон' ? 'risk' : 'mid';
  const marketLevel = ans.stop === 'Не понимаю рынок труда' ? 'risk' : 'mid';
  return /*#__PURE__*/React.createElement("main", {
    className: "container",
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("nav", {
    className: "breadcrumbs"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('home');
    }
  }, "\u0413\u043B\u0430\u0432\u043D\u0430\u044F"), " \u2192 ", /*#__PURE__*/React.createElement("span", {
    "aria-current": "page"
  }, "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442")), /*#__PURE__*/React.createElement("span", {
    className: "eyebrow"
  }, "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0442\u0435\u0441\u0442\u0430"), /*#__PURE__*/React.createElement("h1", {
    className: "tight",
    style: {
      marginTop: 'var(--space-2)'
    }
  }, knows ? 'Вы знаете, куда идёте' : 'Стоит сначала понять себя'), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      marginTop: 'var(--space-4)'
    }
  }, zone('Интересы и склонности', knowsInterests ? 'ok' : 'risk', knowsInterests ? 'Есть выбранные области' : 'Область пока не выбрана'), zone('Понимание себя', selfLevel, selfLevel === 'risk' ? 'Сильные стороны не названы' : 'Частичное понимание'), zone('Рынок профессий', marketLevel, marketLevel === 'risk' ? 'Картина рынка не ясна' : 'Общее представление есть')), knows ? /*#__PURE__*/React.createElement(Callout, {
    intent: "invite",
    style: {
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.15rem',
      display: 'block',
      marginBottom: 4
    }
  }, "\u0421\u043E\u0431\u0435\u0440\u0451\u043C \u0434\u043B\u044F \u0432\u0430\u0441 \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0443\u0437\u043E\u0432"), "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E \u2014 \u043F\u043E\u043A\u0430\u0436\u0435\u043C \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0432\u0443\u0437\u044B \u0441 \u0444\u0430\u043A\u0442\u0430\u043C\u0438: \u043C\u0435\u0441\u0442\u0430, \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C, \u043E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435.", /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => onNav('catalog')
  }, "\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0432\u0443\u0437\u044B \u2192"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: restart
  }, "\u041F\u0440\u043E\u0439\u0442\u0438 \u0437\u0430\u043D\u043E\u0432\u043E"))) : /*#__PURE__*/React.createElement(Callout, {
    intent: "invite",
    style: {
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.15rem',
      display: 'block',
      marginBottom: 4
    }
  }, "\u0414\u0430\u043B\u044C\u0448\u0435 \u043D\u0443\u0436\u0435\u043D \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442 \u0433\u043B\u0443\u0431\u0436\u0435"), "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442 \u043D\u0430 \xAB\u0447\u0442\u043E \u0435\u0441\u0442\u044C\xBB. \u0427\u0442\u043E\u0431\u044B \u043F\u043E\u043D\u044F\u0442\u044C \u0441\u0438\u043B\u044C\u043D\u044B\u0435 \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u0438 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u0438, \u043D\u0443\u0436\u0435\u043D \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0440\u0430\u0437\u0431\u043E\u0440 \u2014 \u043E\u043D \u043E\u0446\u0438\u0444\u0440\u0443\u0435\u0442 \u0442\u043E, \u0447\u0442\u043E \u0442\u0435\u0441\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430\u043C\u0435\u0442\u0438\u043B.", /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    as: "a",
    href: window.VN_DATA.goalUrl('quiz-result'),
    target: "_blank",
    rel: "noopener",
    icon: /*#__PURE__*/React.createElement(I.Sparkle, {
      size: 18
    })
  }, "\u041E\u0446\u0438\u0444\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0438\u043B\u044C\u043D\u044B\u0435 \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u2192"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => onNav('catalog')
  }, "\u041F\u043E\u043A\u0430 \u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0432\u0443\u0437\u044B"))), /*#__PURE__*/React.createElement("p", {
    className: "missing",
    style: {
      fontSize: '.8125rem',
      marginTop: 'var(--space-6)'
    }
  }, "\u041F\u0435\u0440\u0435\u0445\u043E\u0434 \u043A \u0440\u0430\u0437\u0431\u043E\u0440\u0443 \u0432\u0435\u0434\u0451\u0442 \u043D\u0430 \u0446\u0435\u043B\u044C \u0438\u0437 \u0440\u0435\u0435\u0441\u0442\u0440\u0430 \u0441 UTM-\u043C\u0435\u0442\u043A\u043E\u0439; \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0442\u0435\u0441\u0442\u0430 \u043E\u0441\u0442\u0430\u0451\u0442\u0441\u044F \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435."));
}
window.VNQuiz = VNQuiz;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/QuizScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/VuzScreen.jsx
try { (() => {
/* University card — the platform's primary page. Header + fact badges, fact
   strip, programmes folded by level, admission links, FAQ from facts, the
   conversion invite AFTER the programmes block, and "similar" nearby. */
function VNVuz({
  vuz,
  onNav,
  onOpenVuz
}) {
  const DS = window.MainExpertsDesignSystem_96585d;
  const {
    Badge,
    FactList,
    LevelGroup,
    DataTable,
    Callout,
    Button,
    Missing,
    Breadcrumbs,
    Card
  } = DS;
  const {
    vuzy,
    meta
  } = window.VN_DATA;
  const I = window.VNIcons;
  const fmt = n => n.toLocaleString('ru-RU');
  const costPhrase = (a, b) => a === b ? `${fmt(a)} ₽ в год` : `от ${fmt(a)} до ${fmt(b)} ₽ в год`;
  const dirRow = d => {
    const budget = d.offers.filter(o => o.placeType === 'бюджет').reduce((s, o) => s + (o.places || 0), 0);
    const paid = d.offers.filter(o => o.placeType === 'платно').reduce((s, o) => s + (o.places || 0), 0);
    const paidOffer = d.offers.find(o => o.placeType === 'платно' && o.cost != null);
    const forms = [...new Set(d.offers.map(o => o.form))].join(', ');
    return {
      dir: /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("strong", {
        style: {
          fontVariantNumeric: 'tabular-nums'
        }
      }, d.okso), " ", d.name),
      form: forms,
      budget: budget || null,
      paid: paid || null,
      cost: paidOffer ? `${fmt(paidOffer.cost)} ₽` : null,
      _start: true
    };
  };
  const faq = [];
  faq.push({
    q: `Есть ли бюджетные места в «${vuz.short}»?`,
    a: vuz.budget ? 'Да, в выгрузке заявлены бюджетные места (основные места в рамках КЦП и квоты).' : `В выгрузке от ${meta.snapshot} бюджетные места не указаны.`
  });
  faq.push({
    q: 'Сколько стоит платное обучение?',
    a: `По данным выгрузки — ${costPhrase(vuz.costMin, vuz.costMax)}.`
  });
  faq.push({
    q: 'Есть ли общежитие?',
    a: vuz.dormitory ? vuz.dormPlaces ? `Да. Мест в общежитии по данным выгрузки: ${fmt(vuz.dormPlaces)}.` : 'Да, общежитие заявлено. Число мест в выгрузке не указано.' : `В выгрузке от ${meta.snapshot} общежитие не указано.`
  });
  if (vuz.military) faq.push({
    q: 'Есть ли военная кафедра?',
    a: 'Да, военный учебный центр заявлен в данных.'
  });
  const similar = vuzy.filter(v => v.id !== vuz.id && (v.city === vuz.city || v.region === vuz.region)).slice(0, 3);
  const similarFallback = similar.length ? similar : vuzy.filter(v => v.id !== vuz.id).slice(0, 3);
  const cols = [{
    key: 'dir',
    label: 'Направление'
  }, {
    key: 'form',
    label: 'Форма'
  }, {
    key: 'budget',
    label: 'Бюджет',
    num: true
  }, {
    key: 'paid',
    label: 'Платно',
    num: true
  }, {
    key: 'cost',
    label: 'Стоимость',
    num: true
  }];
  return /*#__PURE__*/React.createElement("main", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: [{
      name: 'Главная',
      href: '#'
    }, {
      name: vuz.city,
      href: '#'
    }, {
      name: vuz.short
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(window.VNMono, {
    name: vuz.short,
    size: 64,
    radius: 16,
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      marginBottom: 4
    }
  }, vuz.short), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      marginTop: 0
    }
  }, vuz.full))), /*#__PURE__*/React.createElement("div", {
    className: "badges"
  }, vuz.budget && /*#__PURE__*/React.createElement(Badge, {
    tone: "ok"
  }, "\u0415\u0441\u0442\u044C \u0431\u044E\u0434\u0436\u0435\u0442\u043D\u044B\u0435 \u043C\u0435\u0441\u0442\u0430"), vuz.dormitory && /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "\u041E\u0431\u0449\u0435\u0436\u0438\u0442\u0438\u0435"), vuz.military && /*#__PURE__*/React.createElement(Badge, {
    tone: "info"
  }, "\u0412\u043E\u0435\u043D\u043D\u0430\u044F \u043A\u0430\u0444\u0435\u0434\u0440\u0430"), /*#__PURE__*/React.createElement(window.VNConv.TrustBadge, {
    style: {
      marginLeft: 4
    }
  })), /*#__PURE__*/React.createElement(FactList, {
    items: [{
      label: 'Направлений',
      value: fmt(vuz.directionsCount)
    }, {
      label: 'Уровни',
      value: vuz.levels.join(', ')
    }, {
      label: 'Стоимость (платно)',
      value: costPhrase(vuz.costMin, vuz.costMax)
    }, {
      label: 'Мест в общежитии',
      value: vuz.dormPlaces ? fmt(vuz.dormPlaces) : null
    }, {
      label: 'Телефон',
      value: vuz.phones[0]
    }, {
      label: 'Сайт',
      value: vuz.sites[0] ? /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault()
      }, vuz.sites[0]) : null
    }]
  }), /*#__PURE__*/React.createElement("h2", null, "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u044F"), vuz.programs.map(p => /*#__PURE__*/React.createElement(LevelGroup, {
    key: p.level,
    title: p.level,
    summary: `${p.dirs.length} ${p.dirs.length === 1 ? 'направление' : 'направления'}`,
    defaultOpen: p === vuz.programs[0]
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: cols,
    rows: p.dirs.map(dirRow)
  }))), /*#__PURE__*/React.createElement(Callout, {
    intent: "invite"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      flexWrap: 'wrap',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '48ch'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--display)',
      fontSize: '1.15rem',
      display: 'block',
      marginBottom: 4
    }
  }, "\u0424\u0430\u043A\u0442\u044B \u0441\u043E\u0431\u0440\u0430\u043D\u044B. \u041D\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u043B\u0438 \u0432\u0430\u043C \xAB", vuz.short, "\xBB?"), "\u0411\u0430\u0437\u0430 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442 \u043D\u0430 \xAB\u0447\u0442\u043E \u0435\u0441\u0442\u044C\xBB. \u041D\u0430 \xAB\u0447\u0442\u043E \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0438\u043C\u0435\u043D\u043D\u043E \u0432\u0430\u043C\xBB \u2014 \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u0439 \u0442\u0435\u0441\u0442 \u043D\u0430 5\u20137 \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432, \u0431\u0435\u0437 \u043B\u0438\u0447\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => onNav('test')
  }, "\u041F\u0440\u043E\u0439\u0442\u0438 \u0442\u0435\u0441\u0442 \u2192"))), /*#__PURE__*/React.createElement("h2", null, "\u041F\u0440\u0438\u0451\u043C\u043D\u0430\u044F \u043A\u0430\u043C\u043F\u0430\u043D\u0438\u044F ", meta.campaign), /*#__PURE__*/React.createElement("div", {
    className: "badges"
  }, Object.keys(vuz.usefulLinks).map(k => /*#__PURE__*/React.createElement("a", {
    key: k,
    className: "badge",
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      textDecoration: 'none'
    }
  }, k, " \u2192"))), /*#__PURE__*/React.createElement("h2", null, "\u0427\u0430\u0441\u0442\u044B\u0435 \u0432\u043E\u043F\u0440\u043E\u0441\u044B"), /*#__PURE__*/React.createElement("dl", {
    className: "faq"
  }, faq.map(f => /*#__PURE__*/React.createElement(React.Fragment, {
    key: f.q
  }, /*#__PURE__*/React.createElement("dt", null, f.q), /*#__PURE__*/React.createElement("dd", null, f.a)))), /*#__PURE__*/React.createElement("h2", null, "\u0420\u044F\u0434\u043E\u043C \u0438 \u043F\u043E\u0445\u043E\u0436\u0435"), /*#__PURE__*/React.createElement("ul", {
    className: "card-list grid-3"
  }, similarFallback.map(v => /*#__PURE__*/React.createElement("li", {
    key: v.id
  }, /*#__PURE__*/React.createElement(Card, {
    title: v.short,
    href: "#",
    icon: /*#__PURE__*/React.createElement(window.VNMono, {
      name: v.short,
      size: 40,
      radius: 11
    }),
    meta: [v.city, `${v.directionsCount} направлений`, `от ${fmt(v.costMin)} ₽ в год`],
    onClick: e => {
      e.preventDefault();
      onOpenVuz(v);
    },
    style: {
      cursor: 'pointer'
    }
  })))), /*#__PURE__*/React.createElement("p", {
    className: "missing",
    style: {
      fontSize: '.8125rem',
      borderTop: '1px solid var(--border)',
      paddingTop: 'var(--space-4)',
      fontStyle: 'normal',
      color: 'var(--text-muted)'
    }
  }, "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A: ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text)'
    }
  }, meta.source), " \xB7 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0430 \u043E\u0442 ", meta.snapshot, " \xB7 \u043F\u0440\u0438\u0451\u043C ", meta.campaign, ". \u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435; \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0439\u0442\u0435 \u043D\u0430 \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u043C \u0441\u0430\u0439\u0442\u0435 \u0432\u0443\u0437\u0430."), /*#__PURE__*/React.createElement(window.VNConv.PinnedCTA, {
    placement: "vuz-pinned"
  }));
}
window.VNVuz = VNVuz;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/VuzScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/app.jsx
try { (() => {
/* App shell — screen state + navigation for the click-through. */
function VNApp() {
  const [screen, setScreen] = React.useState('home');
  const [vuz, setVuz] = React.useState(null);
  const top = () => {
    try {
      window.scrollTo(0, 0);
    } catch (e) {}
  };
  const nav = s => {
    setScreen(s);
    top();
  };
  const openVuz = v => {
    setVuz(v);
    setScreen('vuz');
    top();
  };
  let body;
  switch (screen) {
    case 'catalog':
    case 'regions':
    case 'directions':
      body = /*#__PURE__*/React.createElement(window.VNCatalog, {
        onOpenVuz: openVuz
      });
      break;
    case 'vuz':
      body = /*#__PURE__*/React.createElement(window.VNVuz, {
        vuz: vuz || window.VN_DATA.vuzy[0],
        onNav: nav,
        onOpenVuz: openVuz
      });
      break;
    case 'compare':
      body = /*#__PURE__*/React.createElement(window.VNCompare, {
        onOpenVuz: openVuz
      });
      break;
    case 'test':
      body = /*#__PURE__*/React.createElement(window.VNQuiz, {
        onNav: nav
      });
      break;
    default:
      body = /*#__PURE__*/React.createElement(window.VNHome, {
        onNav: nav,
        onOpenVuz: openVuz
      });
  }
  const current = screen === 'vuz' ? 'catalog' : screen;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.VNHeader, {
    onNav: nav,
    current: current
  }), body, /*#__PURE__*/React.createElement(window.VNFooter, null), /*#__PURE__*/React.createElement(window.VNConv.ExitIntent, {
    onQuiz: () => nav('test')
  }));
}
const VN_ROOT_EL = document.getElementById('root');
VN_ROOT_EL._vnRoot = VN_ROOT_EL._vnRoot || ReactDOM.createRoot(VN_ROOT_EL);
VN_ROOT_EL._vnRoot.render(/*#__PURE__*/React.createElement(VNApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/conversion.jsx
try { (() => {
/* Conversion + trust building blocks: provenance badge, cost histogram,
   pinned goal CTA (after 40% scroll), and a once-per-session exit-intent
   that offers the quiz — never a purchase. */
(function () {
  const DS = () => window.MainExpertsDesignSystem_96585d;

  // Trust: "official export · date" — turns YMYL rigour into a selling point.
  function TrustBadge({
    style
  }) {
    const I = window.VNIcons;
    const {
      meta
    } = window.VN_DATA;
    return React.createElement('span', {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        padding: '5px 12px',
        borderRadius: 999,
        background: 'var(--ok-soft)',
        color: 'var(--ok)',
        fontSize: '.8rem',
        fontWeight: 600,
        ...style
      }
    }, React.createElement(I.Check, {
      size: 15
    }), `Официальная выгрузка · ${meta.snapshot}`);
  }

  // Cost distribution bars above the price slider. Buckets above the current
  // ceiling dim out.
  function CostHistogram({
    maxCost
  }) {
    const {
      costHistogram
    } = window.VN_DATA;
    const maxN = Math.max(...costHistogram.map(b => b.n));
    const ceil = maxCost / 1000;
    return React.createElement('div', {
      style: {
        display: 'flex',
        alignItems: 'flex-end',
        gap: 3,
        height: 40,
        margin: '2px 0 8px'
      }
    }, costHistogram.map((b, i) => {
      const lo = i === 0 ? 0 : costHistogram[i - 1].to;
      const active = lo < ceil;
      return React.createElement('div', {
        key: b.to,
        title: `до ${b.to} тыс. ₽`,
        style: {
          flex: 1,
          height: `${Math.round(b.n / maxN * 100)}%`,
          borderRadius: '3px 3px 0 0',
          background: active ? 'linear-gradient(135deg, var(--grad-a), var(--grad-b))' : 'var(--surface-2)',
          transition: 'background .15s ease'
        }
      });
    }));
  }

  // Pinned goal CTA — reserved (fixed) so no layout shift; reveals past 40%.
  function PinnedCTA({
    placement = 'pinned',
    label = 'Пройти скрининг',
    sub = 'Понять, что подходит именно вам'
  }) {
    const {
      Button
    } = DS();
    const I = window.VNIcons;
    const [show, setShow] = React.useState(false);
    React.useEffect(() => {
      const on = () => {
        const h = document.documentElement;
        const denom = h.scrollHeight - h.clientHeight || 1;
        setShow(window.scrollY / denom > 0.4);
      };
      window.addEventListener('scroll', on, {
        passive: true
      });
      on();
      return () => window.removeEventListener('scroll', on);
    }, []);
    return React.createElement('div', {
      style: {
        position: 'fixed',
        right: 16,
        bottom: 16,
        zIndex: 40,
        maxWidth: 320,
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '12px 14px',
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 14,
        boxShadow: 'var(--shadow-2)',
        transition: 'opacity .2s ease, transform .2s ease',
        opacity: show ? 1 : 0,
        transform: show ? 'none' : 'translateY(12px)',
        pointerEvents: show ? 'auto' : 'none'
      }
    }, React.createElement('div', {
      style: {
        minWidth: 0
      }
    }, React.createElement('div', {
      style: {
        fontWeight: 600,
        fontSize: '.9rem'
      }
    }, label), React.createElement('div', {
      className: 'meta',
      style: {
        fontSize: '.78rem'
      }
    }, sub)), React.createElement(Button, {
      as: 'a',
      size: 'sm',
      href: window.VN_DATA.goalUrl(placement),
      target: '_blank',
      rel: 'noopener',
      icon: React.createElement(I.ArrowRight, {
        size: 16
      })
    }));
  }

  // Exit-intent (desktop): offers the quiz, once per session.
  function ExitIntent({
    onQuiz
  }) {
    const {
      Button
    } = DS();
    const [open, setOpen] = React.useState(false);
    React.useEffect(() => {
      let done = false;
      try {
        done = sessionStorage.getItem('vn_exit') === '1';
      } catch (e) {}
      if (done) return;
      const on = e => {
        if (e.clientY <= 0) {
          setOpen(true);
          try {
            sessionStorage.setItem('vn_exit', '1');
          } catch (e2) {}
          window.removeEventListener('mouseout', on);
        }
      };
      window.addEventListener('mouseout', on);
      return () => window.removeEventListener('mouseout', on);
    }, []);
    if (!open) return null;
    const close = () => setOpen(false);
    return React.createElement('div', {
      onClick: close,
      style: {
        position: 'fixed',
        inset: 0,
        zIndex: 80,
        background: 'rgba(42,32,24,.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20
      }
    }, React.createElement('div', {
      onClick: e => e.stopPropagation(),
      style: {
        background: 'var(--surface)',
        borderRadius: 18,
        boxShadow: 'var(--shadow-2)',
        maxWidth: 440,
        padding: 28,
        position: 'relative'
      }
    }, React.createElement('button', {
      onClick: close,
      'aria-label': 'Закрыть',
      style: {
        position: 'absolute',
        top: 12,
        right: 14,
        background: 'none',
        border: 0,
        fontSize: '1.3rem',
        cursor: 'pointer',
        color: 'var(--text-muted)',
        lineHeight: 1
      }
    }, '✕'), React.createElement('div', {
      className: 'eyebrow',
      style: {
        margin: 0
      }
    }, 'Прежде чем уйти'), React.createElement('h2', {
      style: {
        margin: '6px 0 8px'
      }
    }, 'Вы знаете 7–10 профессий, а их 250 000+'), React.createElement('p', {
      style: {
        marginTop: 0,
        color: 'var(--text-muted)'
      }
    }, 'Короткий тест на 5–7 вопросов покажет, с чего начать выбор — без личных данных, результат останется в браузере.'), React.createElement('div', {
      style: {
        display: 'flex',
        gap: 12,
        flexWrap: 'wrap',
        marginTop: 8
      }
    }, React.createElement(Button, {
      variant: 'primary',
      onClick: () => {
        onQuiz && onQuiz();
        close();
      }
    }, 'Пройти тест'), React.createElement(Button, {
      variant: 'secondary',
      onClick: close
    }, 'Не сейчас'))));
  }
  window.VNConv = {
    TrustBadge,
    CostHistogram,
    PinnedCTA,
    ExitIntent
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/conversion.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/data.js
try { (() => {
/* Sample data for the ВУЗ-навигатор UI kit. Illustrative values in the real
   OrgCard shape (see app/src/lib/data.ts). Facet counts are plausible, not live.
   window global so Babel islands can read it. */
window.VN_DATA = function () {
  const meta = {
    snapshot: '10.07.2026',
    campaign: '2026/27',
    source: 'ВУЗ-навигатор'
  };
  const stats = {
    vuzy: 1785,
    goroda: 358,
    regiony: 87,
    napravleniya: 894,
    ugs: 57,
    stranicy: 9440,
    medianaPaid: 190000,
    budgetShare: 78
  };
  const cities = [{
    slug: 'moskva',
    name: 'Москва',
    count: 336
  }, {
    slug: 'sankt-peterburg',
    name: 'Санкт-Петербург',
    count: 78
  }, {
    slug: 'ekaterinburg',
    name: 'Екатеринбург',
    count: 28
  }, {
    slug: 'kazan',
    name: 'Казань',
    count: 24
  }, {
    slug: 'novosibirsk',
    name: 'Новосибирск',
    count: 21
  }, {
    slug: 'nizhniy-novgorod',
    name: 'Нижний Новгород',
    count: 19
  }, {
    slug: 'rostov-na-donu',
    name: 'Ростов-на-Дону',
    count: 17
  }, {
    slug: 'samara',
    name: 'Самара',
    count: 15
  }];
  const ugs = [{
    code: '09',
    name: 'Информатика и вычислительная техника',
    dirs: 11,
    vuzy: 612
  }, {
    code: '38',
    name: 'Экономика и управление',
    dirs: 19,
    vuzy: 987
  }, {
    code: '40',
    name: 'Юриспруденция',
    dirs: 4,
    vuzy: 741
  }, {
    code: '01',
    name: 'Математика и механика',
    dirs: 8,
    vuzy: 214
  }, {
    code: '03',
    name: 'Физика и астрономия',
    dirs: 5,
    vuzy: 156
  }, {
    code: '45',
    name: 'Языкознание и литературоведение',
    dirs: 7,
    vuzy: 298
  }];

  // Detailed university cards.
  const vuzy = [{
    id: '1147',
    slug: 'mgu-1147',
    short: 'МГУ им. М. В. Ломоносова',
    full: 'Московский государственный университет имени М. В. Ломоносова',
    city: 'Москва',
    citySlug: 'moskva',
    region: 'Москва',
    directionsCount: 58,
    costMin: 391800,
    costMax: 495000,
    budget: true,
    dormitory: true,
    dormPlaces: 6000,
    military: true,
    phones: ['+7 495 939-10-00'],
    sites: ['msu.ru'],
    levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '01.03.02',
        name: 'Прикладная математика и информатика',
        ugs: '01',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 120,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 45,
          cost: 391800
        }]
      }, {
        okso: '03.03.02',
        name: 'Физика',
        ugs: '03',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 95,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 20,
          cost: 391800
        }]
      }, {
        okso: '38.03.01',
        name: 'Экономика',
        ugs: '38',
        offers: [{
          form: 'очная',
          placeType: 'платно',
          places: 60,
          cost: 495000
        }]
      }]
    }, {
      level: 'Магистратура',
      dirs: [{
        okso: '01.04.02',
        name: 'Прикладная математика и информатика',
        ugs: '01',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 80,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 15,
          cost: 410000
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#',
      'Перечень олимпиад': '#',
      'Стоимость обучения': '#'
    }
  }, {
    id: '2032',
    slug: 'itmo-2032',
    short: 'Университет ИТМО',
    full: 'Национальный исследовательский университет ИТМО',
    city: 'Санкт-Петербург',
    citySlug: 'sankt-peterburg',
    region: 'Санкт-Петербург',
    directionsCount: 32,
    costMin: 284000,
    costMax: 372000,
    budget: true,
    dormitory: true,
    dormPlaces: 3200,
    military: false,
    phones: ['+7 812 480-00-00'],
    sites: ['itmo.ru'],
    levels: ['Бакалавриат', 'Магистратура'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '09.03.01',
        name: 'Информатика и вычислительная техника',
        ugs: '09',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 210,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 90,
          cost: 372000
        }]
      }, {
        okso: '09.03.04',
        name: 'Программная инженерия',
        ugs: '09',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 120,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 60,
          cost: 372000
        }]
      }]
    }, {
      level: 'Магистратура',
      dirs: [{
        okso: '09.04.01',
        name: 'Информатика и вычислительная техника',
        ugs: '09',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 140,
          cost: null
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#',
      'Достижения': '#'
    }
  }, {
    id: '0891',
    slug: 'spbgu-0891',
    short: 'СПбГУ',
    full: 'Санкт-Петербургский государственный университет',
    city: 'Санкт-Петербург',
    citySlug: 'sankt-peterburg',
    region: 'Санкт-Петербург',
    directionsCount: 54,
    costMin: 268000,
    costMax: 448000,
    budget: true,
    dormitory: true,
    dormPlaces: null,
    military: true,
    phones: ['+7 812 328-20-00'],
    sites: ['spbu.ru'],
    levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '40.03.01',
        name: 'Юриспруденция',
        ugs: '40',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 100,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 180,
          cost: 448000
        }]
      }, {
        okso: '45.03.01',
        name: 'Филология',
        ugs: '45',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 75,
          cost: null
        }, {
          form: 'очно-заочная',
          placeType: 'платно',
          places: 40,
          cost: 268000
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#',
      'Апелляции': '#',
      'Олимпиады': '#'
    }
  }, {
    id: '3310',
    slug: 'mfti-3310',
    short: 'МФТИ',
    full: 'Московский физико-технический институт (национальный исследовательский университет)',
    city: 'Долгопрудный',
    citySlug: 'dolgoprudnyy',
    region: 'Московская область',
    directionsCount: 16,
    costMin: 396000,
    costMax: 396000,
    budget: true,
    dormitory: true,
    dormPlaces: 4100,
    military: true,
    phones: ['+7 495 408-45-54'],
    sites: ['mipt.ru'],
    levels: ['Бакалавриат', 'Магистратура'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '03.03.01',
        name: 'Прикладные математика и физика',
        ugs: '03',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 900,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 120,
          cost: 396000
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#'
    }
  }, {
    id: '1904',
    slug: 'hse-1904',
    short: 'НИУ ВШЭ',
    full: 'Национальный исследовательский университет «Высшая школа экономики»',
    city: 'Москва',
    citySlug: 'moskva',
    region: 'Москва',
    directionsCount: 63,
    costMin: 390000,
    costMax: 770000,
    budget: true,
    dormitory: true,
    dormPlaces: 5400,
    military: false,
    phones: ['+7 495 771-32-42'],
    sites: ['hse.ru'],
    levels: ['Бакалавриат', 'Магистратура'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '38.03.01',
        name: 'Экономика',
        ugs: '38',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 60,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 300,
          cost: 770000
        }]
      }, {
        okso: '09.03.04',
        name: 'Программная инженерия',
        ugs: '09',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 80,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 120,
          cost: 610000
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#',
      'Индивидуальные достижения': '#'
    }
  }, {
    id: '2571',
    slug: 'kfu-2571',
    short: 'КФУ',
    full: 'Казанский (Приволжский) федеральный университет',
    city: 'Казань',
    citySlug: 'kazan',
    region: 'Республика Татарстан',
    directionsCount: 71,
    costMin: 138000,
    costMax: 226000,
    budget: true,
    dormitory: true,
    dormPlaces: 8100,
    military: true,
    phones: ['+7 843 233-71-09'],
    sites: ['kpfu.ru'],
    levels: ['Бакалавриат', 'Магистратура', 'Специалитет'],
    programs: [{
      level: 'Бакалавриат',
      dirs: [{
        okso: '38.03.01',
        name: 'Экономика',
        ugs: '38',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 120,
          cost: null
        }, {
          form: 'заочная',
          placeType: 'платно',
          places: 200,
          cost: 138000
        }]
      }, {
        okso: '40.03.01',
        name: 'Юриспруденция',
        ugs: '40',
        offers: [{
          form: 'очная',
          placeType: 'бюджет',
          places: 90,
          cost: null
        }, {
          form: 'очная',
          placeType: 'платно',
          places: 150,
          cost: 226000
        }]
      }]
    }],
    usefulLinks: {
      'Правила приёма': '#',
      'Общежития': '#'
    }
  }];

  // Active conversion goal (registry, single URL) — dev screening for now.
  const goal = {
    base: 'https://dev.mainexperts.online/screening'
  };
  function goalUrl(placement) {
    const u = new URL(goal.base);
    u.searchParams.set('utm_source', 'vuznavigator');
    u.searchParams.set('utm_medium', placement || 'cta');
    u.searchParams.set('utm_campaign', 'screening');
    return u.toString();
  }

  // Illustrative paid-tuition distribution (median 190k, quartiles 158–270k).
  // Each bucket: upper bound in thousands ₽/year + count.
  const costHistogram = [{
    to: 100,
    n: 3
  }, {
    to: 150,
    n: 9
  }, {
    to: 190,
    n: 16
  }, {
    to: 230,
    n: 14
  }, {
    to: 270,
    n: 11
  }, {
    to: 320,
    n: 7
  }, {
    to: 400,
    n: 5
  }, {
    to: 520,
    n: 3
  }, {
    to: 800,
    n: 2
  }];
  return {
    meta,
    stats,
    cities,
    ugs,
    vuzy,
    goal,
    goalUrl,
    costHistogram
  };
}();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/data.js", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/icons.jsx
try { (() => {
/* Thin-line UI icons for the kit. The source platform ships NO icon library —
   it uses small inline SVGs + CSS shapes. These match that style: 24×24,
   fill none, stroke currentColor, width 2, round joins (Lucide-like geometry). */
(function () {
  const S = ({
    children,
    size = 20,
    ...p
  }) => React.createElement('svg', {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': true,
    ...p
  }, children);
  const P = d => React.createElement('path', {
    d
  });
  const L = (x1, y1, x2, y2) => React.createElement('line', {
    x1,
    y1,
    x2,
    y2
  });
  const C = (cx, cy, r) => React.createElement('circle', {
    cx,
    cy,
    r
  });
  const POLY = (points, el = 'polyline') => React.createElement(el, {
    points
  });
  const Icon = nodes => props => S({
    ...props,
    children: nodes().map((n, i) => React.cloneElement(n, {
      key: i
    }))
  });
  window.VNIcons = {
    Search: Icon(() => [C(11, 11, 8), L(21, 21, 16.65, 16.65)]),
    Filter: Icon(() => [POLY('22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3', 'polygon')]),
    Heart: Icon(() => [P('M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8L12 21l7.8-8.6a5.5 5.5 0 0 0 0-7.8z')]),
    Compare: Icon(() => [P('M8 3 4 7l4 4'), L(4, 7, 20, 7), P('M16 21l4-4-4-4'), L(20, 17, 4, 17)]),
    MapPin: Icon(() => [P('M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z'), C(12, 10, 3)]),
    ArrowRight: Icon(() => [L(5, 12, 19, 12), POLY('12 5 19 12 12 19')]),
    Check: Icon(() => [POLY('20 6 9 17 4 12')]),
    X: Icon(() => [L(18, 6, 6, 18), L(6, 6, 18, 18)]),
    ChevronDown: Icon(() => [POLY('6 9 12 15 18 9')]),
    Cap: Icon(() => [P('M22 10 12 5 2 10l10 5 10-5z'), P('M6 12v5c0 1 2.7 3 6 3s6-2 6-3v-5')]),
    Landmark: Icon(() => [L(3, 22, 21, 22), L(6, 18, 6, 11), L(10, 18, 10, 11), L(14, 18, 14, 11), L(18, 18, 18, 11), POLY('12 2 20 7 4 7', 'polygon')]),
    Compass: Icon(() => [C(12, 12, 10), POLY('16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88', 'polygon')]),
    Book: Icon(() => [P('M4 19.5A2.5 2.5 0 0 1 6.5 17H20'), P('M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z')]),
    Sparkle: Icon(() => [P('M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z')])
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/vuz-navigator/monogram.jsx
try { (() => {
/* Generative university monogram — the on-brand stand-in wherever a real vuz
   logo would go. Deterministic caramel-family colour + the name's acronym.
   Drop-in slot: swap for an <img> logo later with no layout change. */
(function () {
  const PALETTE = ['#9a5a1c', '#7a4413', '#6f3f1c', '#a86a2c', '#8a5a12', '#3f7a2e'];
  function acronym(name) {
    const tokens = String(name || '').split(/\s+/).filter(Boolean);
    let best = tokens[0] || '?';
    let bestCaps = -1;
    for (const t of tokens) {
      const caps = (t.match(/\p{Lu}/gu) || []).length;
      if (caps > bestCaps) {
        bestCaps = caps;
        best = t;
      }
    }
    return best.replace(/[.,]/g, '').slice(0, 5);
  }
  function colorFor(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = h * 31 + str.charCodeAt(i) >>> 0;
    return PALETTE[h % PALETTE.length];
  }
  function VNMono({
    name,
    size = 44,
    radius = 11,
    style
  }) {
    const token = acronym(name);
    const fs = size * (token.length >= 5 ? 0.24 : token.length === 4 ? 0.28 : token.length === 3 ? 0.34 : 0.42);
    return React.createElement('span', {
      'aria-hidden': true,
      style: {
        width: size,
        height: size,
        borderRadius: radius,
        flex: 'none',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: colorFor(token),
        color: '#fff',
        fontFamily: 'var(--sans)',
        fontWeight: 700,
        fontSize: fs,
        letterSpacing: '-.02em',
        lineHeight: 1,
        boxShadow: 'inset 0 -2px 6px rgba(0,0,0,.14)',
        ...style
      }
    }, token);
  }
  window.VNMono = VNMono;
  window.VNMonoAcronym = acronym;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/vuz-navigator/monogram.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Missing = __ds_scope.Missing;

__ds_ns.ZoneChip = __ds_scope.ZoneChip;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.FactList = __ds_scope.FactList;

__ds_ns.LevelGroup = __ds_scope.LevelGroup;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.FilterChip = __ds_scope.FilterChip;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
