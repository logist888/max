# MainExperts — Design System

The brand system for **MainExperts «ВУЗ-навигатор»**: a programmatic-SEO
platform that helps applicants in Russia choose a university by *facts* —
every university, direction, city and price from an official data export —
and then bridges the reader toward MainExperts' career-guidance diagnostics.
It is a warm, editorial, YMYL-trust product: caramel-brown palette, a serif
display face, and a hard rule that data gaps are shown, never faked.

This system was reverse-engineered from the platform's shipped stylesheet,
fonts and logo, plus its written product/IA specification. It ships the real
tokens, the real webfonts, a set of React primitives that render the platform's
CSS vocabulary, and an interactive UI kit recreating the core screens.

---

## Sources

Everything here is grounded in one repository the user provided (nothing is
invented from memory):

- **GitHub:** `logist888/max`, branch **`claude/education-seo-platform-p5k4i8`**,
  subtree **`seo-platform/`** — the SEO-platform design docs (`00-audit` …
  `07-roadmap`, `HISTORY.md`) and the Astro app in `seo-platform/app/`.
- Design foundation lifted verbatim from `seo-platform/app/src/styles/main.css`
  (tokens, fonts, component classes).
- Webfonts copied from `seo-platform/app/public/fonts/` (Inter + Lora, self-hosted).
- Logo + favicon from `seo-platform/app/public/`.
- Product behaviour, copy rules and numbers from `seo-platform/04-product.md`,
  `01-model-ia.md`, `05-tech.md`, `07-roadmap.md`.

The wider `logist888/max` repo (branch `claude/sweet-thompson-o8ml5c`) is a
Russian-language business/strategy vault for the parent MainExperts education
company. If you can access these repos, read them to build more faithfully —
the SEO-platform docs describe card layouts, filter rules and the conversion
model in detail.

> **One product.** The design system covers a single surface — the ВУЗ-навигатор
> website. There is no separate mobile app or second product in the source.

---

## Content fundamentals

**Language.** Russian only, in every artifact. Professional, precise, no
anglicisms and no marketing clichés. Concision beats volume. Accuracy beats
completeness: where a detail is unknown, leave a gap — never invent.

**Voice — "помогает решить, а не продаёт".** The site helps the reader decide;
it does not sell a university. The reader arrives for facts, gets them in full,
meets the honest fork ("facts don't tell you what fits *you*"), and is offered a
next step — phrased as a decision step, not an ad.

- **Do:** «Факты не говорят, что подходит именно вам. Пройти тест →»
- **Don't:** «Лучший вуз страны! Успей подать заявку со скидкой!»

**Address.** Neutral / "вы" (lowercase, not capitalised «Вы») for applicants
and parents; the teen branch of the quiz uses a lighter tone. No emoji — ever.
The brand never uses emoji as decoration or bullets.

**Data integrity (the signature rule).** Every fact traces to an export field.
A gap is rendered explicitly as **«Информация отсутствует»** (the `Missing`
component / `.missing` class), never hidden and never shown as `0 ₽`. Absence of
a positive flag is silence, not a red "no". Every data page carries a
**source + date** line: «Источник: ВУЗ-навигатор · выгрузка от 10.07.2026 ·
приём 2026/27».

**Numbers & units.** Russian grouping with a thin space and the ruble sign after
the number: `190 000 ₽`. Ranges read «от 158 000 до 270 000 ₽ в год». Counts are
pluralised correctly (вуз / вуза / вузов) and set in tabular figures. Test/method
names (Big Five, RIASEC, etc.) are **never published** — only working names.

**Anchor figures** (from the accepted export, good for headings/heroes):
1 785 вузов · 358 городов · 87 регионов · 894 направления · 57 УГСН ·
≈ 9 440 canonical pages · median paid tuition 190 000 ₽/year (quartiles
158–270 k) · budget places at 78 % of universities.

---

## Visual foundations

**Palette — corporate brown-caramel** (owner update 12.07.2026; all text/bg pairs
pass WCAG AA). Warm cream page `#faf6f0`, white cards, caramel-tinted insets
`#f4ece0`; near-black-brown text `#2a2018` / muted `#6d5d4c`. One accent family:
caramel `#9a5a1c` → strong `#7a4413`, soft ground `#f7e9d5`. Semantics double as
the screening product's language: ok green `#3f7a2e`, warn `#8a5a12`, risk
`#c9382f`, each with a soft tint. **At most one or two background colours per
layout.** A dark theme flips the same token names via `prefers-color-scheme`.

**Gradient.** A single signature `linear-gradient(135deg, #a86a2c → #6f3f1c)`
on primary buttons, the nav CTA, the active pager pill, and (richer, three-stop
with radial glows) the hero. Not used as a page background.

**Type.** Two families only. Headings — **Lora** (`--display`), an editorial
serif, with tight tracking (`-.02em` on h1), `text-wrap: balance`, sizes 2.7 /
1.8 / 1.15 rem at desktop. Body & all UI — **Inter** (`--sans`, variable
400–800), 1 rem / 1.55 line-height. Utility labels (filter titles, eyebrows)
stay in Inter — uppercase serif looks poor. Eyebrows: 0.75 rem, 700, 0.08 em
tracking, uppercase, caramel.

**Spacing & radii.** 4-based scale (4 · 8 · 12 · 16 · 24 · 32 · 48). Radii:
14 px cards/panels, 9 px inputs/wraps, 999 px pills. Container max 1200 px.

**Backgrounds & texture.** Flat warm surfaces — no photography, no illustration,
no patterns or noise. The only "imagery" is the brown gradient hero with two soft
radial glows. Depth comes from colour and hairlines, not decoration.

**Borders, cards & elevation.** Warm 1 px hairline `#e8dccb`. Two shadow levels,
both brown-tinted, low-opacity: `shadow-1` (0 1px 2px, .06) at rest, `shadow-2`
(0 10px 30px, .12) on hover. A card = white surface + hairline + `radius:14px` +
`shadow-1`. **Never** a coloured left-border accent card (except the deliberate
`.notice`/`.invite` callouts, which are left-border boxes by design).

**Hover / press.** Cards lift `translateY(-2px)`, gain `shadow-2` and a
caramel-mixed border. Primary buttons lift `-1px` with a deeper shadow;
secondary buttons shift border+text to caramel. Filter chips fill caramel when
pressed (`aria-pressed`). No scale-down press state.

**Motion.** Restrained. 0.15 s ease on hover transforms/shadows; a progressive-
enhancement `.reveal` fade-up (0.5 s) gated behind `.js-motion`; hero stat
count-ups. Everything is disabled under `prefers-reduced-motion`. No bounces,
no springy easing.

**Transparency & blur.** One place: the sticky header — `color-mix` 82 % bg +
`backdrop-filter: blur(12px)`. Hero chips use translucent white on the dark
gradient. Otherwise surfaces are solid.

**Layout rules.** Sticky blurred header; left/inline faceted filter panel on
desktop that becomes a right-side drawer under 768 px; a burger nav under
1024 px; conversion CTAs reserve their space (no layout shift) and appear only
after the useful content.

---

## Iconography

The source platform **ships no icon library** — it draws a few inline SVGs and
uses CSS shapes (the filter funnel is a `clip-path`, the burger is pseudo-element
bars, the accordion chevron is a `▾` glyph). There is no icon font, sprite, or
committed SVG set in the repo, and no emoji or unicode icons in the UI.

Because there was nothing to copy, the UI kit uses a small set of **thin-line
inline SVG glyphs** (`ui_kits/vuz-navigator/icons.jsx`) authored to match that
style: 24×24, `fill:none`, `stroke:currentColor`, width 2, round caps — Lucide-
like geometry. **This is a substitution** (search, filter, heart, compare,
map-pin, arrow, check, close, chevron, graduation cap, landmark, compass, book,
sparkle). If MainExperts standardises on an icon set, replace this file and the
platform's inline SVGs will follow the same weight/style.

The brand mark is the real caramel `logo.png` from the repo (95×69, low-res). No
logo was drawn or reconstructed. See `assets/`.

---

## What's inside (index)

Root files:
- `styles.css` — global entry point (link this one file). `@import`s only.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`.
- `base.css` — element defaults (reset, headings, links, reduced-motion).
- `components.css` — the platform's full CSS component vocabulary.
- `assets/` — `logo.png`, `favicon.png`, `fonts/` (Inter + Lora woff2, cyr+lat).
- `guidelines/` — 12 foundation specimen cards (Colors, Type, Spacing, Brand).
- `components/` — React primitives (below).
- `ui_kits/vuz-navigator/` — interactive product recreation (see its README).
- `thumbnail.html` — homepage tile. `SKILL.md` — portable skill wrapper.

Components (`window.MainExpertsDesignSystem_96585d`), 13 in three groups:
- **core** — `Button`, `Badge`, `ZoneChip`, `Callout`, `Missing`.
- **navigation** — `Breadcrumbs`, `Tabs`, `Pagination`, `FilterChip`.
- **data** — `Card`, `FactList`, `LevelGroup`, `DataTable`.

Each component has a `.d.ts` props contract and a `.prompt.md` with a usage
example; each group directory has an `@dsCard` showcase HTML.

The component inventory mirrors the vocabulary defined in the source CSS
(`main.css` references, e.g., `Filters.astro` and an `OrgRow` component). It is
not a generic "standard set" — there is no Dialog/Tooltip/Avatar here because the
source defines none.

**Intentional additions**
- `icons.jsx` (UI kit) — a thin-line glyph set, since the source ships no icons
  (see Iconography). Kept inside the UI kit, not exposed as a DS component.
- `ZoneChip` / `Callout(invite)` — promoted to first-class components because the
  conversion + screening language (`.zone-chip`, `.invite`) is central to the
  brand, even though the source expresses them as CSS classes.

**Substitutions to confirm with the owner**
- **Icons** — thin-line inline SVGs stand in for a non-existent source set.
- **Logo** — the only mark available is a 95×69 px PNG; a vector/hi-res version
  would render far better in the header and thumbnail.

Fonts are the **real** self-hosted Inter + Lora woff2 from the repo — no font
substitution was needed.
